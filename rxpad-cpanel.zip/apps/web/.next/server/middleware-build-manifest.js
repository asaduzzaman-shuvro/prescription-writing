globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/xVMtQtyczzdp9RV3fvfTh/_buildManifest.js",
    "static/xVMtQtyczzdp9RV3fvfTh/_ssgManifest.js",
    "static/xVMtQtyczzdp9RV3fvfTh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3obq3ebsc4o8x.js",
    "static/chunks/1adqndze20k9e.js",
    "static/chunks/0odwda0mwxy6x.js",
    "static/chunks/312j43r7sd0xd.js",
    "static/chunks/turbopack-3dsjxu1aabls-.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
