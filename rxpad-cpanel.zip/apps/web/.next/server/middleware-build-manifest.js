globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/kh-LgRWrGg_36oqK-bWBv/_buildManifest.js",
    "static/kh-LgRWrGg_36oqK-bWBv/_ssgManifest.js",
    "static/kh-LgRWrGg_36oqK-bWBv/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/21ju5v4si1-i-.js",
    "static/chunks/15ux7vy9g5h7v.js",
    "static/chunks/3aeeguh5xlz48.js",
    "static/chunks/0wjbe566_zbqm.js",
    "static/chunks/turbopack-3y34yr4w3p_uo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
