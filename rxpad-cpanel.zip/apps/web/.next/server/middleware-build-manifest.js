globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/8D-wZ4UWRK7YPPTRfeBxt/_buildManifest.js",
    "static/8D-wZ4UWRK7YPPTRfeBxt/_ssgManifest.js",
    "static/8D-wZ4UWRK7YPPTRfeBxt/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/21ju5v4si1-i-.js",
    "static/chunks/39v83g2zzq40a.js",
    "static/chunks/3aeeguh5xlz48.js",
    "static/chunks/3g1cphiir02yk.js",
    "static/chunks/turbopack-325py472wkcmx.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
