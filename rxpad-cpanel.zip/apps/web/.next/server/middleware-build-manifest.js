globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/66rqnBQSp_Il0mtAqks3X/_buildManifest.js",
    "static/66rqnBQSp_Il0mtAqks3X/_ssgManifest.js",
    "static/66rqnBQSp_Il0mtAqks3X/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3obq3ebsc4o8x.js",
    "static/chunks/06qxf1__wd88y.js",
    "static/chunks/0odwda0mwxy6x.js",
    "static/chunks/1d2yqdk6odo8o.js",
    "static/chunks/turbopack-0vkivbsglbxtw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
