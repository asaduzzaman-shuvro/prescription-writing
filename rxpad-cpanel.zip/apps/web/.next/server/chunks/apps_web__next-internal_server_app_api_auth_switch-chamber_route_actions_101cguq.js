module.exports=[23231,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_auth_switch-chamber_route_actions_101cguq.js.map