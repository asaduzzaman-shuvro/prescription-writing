module.exports=[82854,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_web__next-internal_server_app_api_fhir_prescription_%5Bid%5D_route_actions_0rnywiq.js.map