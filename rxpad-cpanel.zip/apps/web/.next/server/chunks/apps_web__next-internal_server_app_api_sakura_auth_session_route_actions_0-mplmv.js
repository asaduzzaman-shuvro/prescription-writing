module.exports=[73813,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_sakura_auth_session_route_actions_0-mplmv.js.map