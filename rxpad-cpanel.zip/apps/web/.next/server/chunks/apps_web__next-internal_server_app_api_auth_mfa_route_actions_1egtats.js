module.exports=[4037,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_auth_mfa_route_actions_1egtats.js.map