module.exports=[88329,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_sakura_%5B___path%5D_route_actions_05q_w1k.js.map