module.exports=[78215,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_sakura_auth_logout_route_actions_1ixrczd.js.map