module.exports=[34997,s=>{"use strict";s.s([])}];

//# sourceMappingURL=0gy1__next-internal_server_app_api_admin_catalogue_template_route_actions_1cbfqpx.js.map