module.exports=[20177,s=>{"use strict";s.s([])}];

//# sourceMappingURL=0gy1__next-internal_server_app_api_print_lab_%5BrequestId%5D_pdf_route_actions_19_8cz5.js.map