module.exports=[87965,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_lab-files_%5Bid%5D_route_actions_18n0nav.js.map