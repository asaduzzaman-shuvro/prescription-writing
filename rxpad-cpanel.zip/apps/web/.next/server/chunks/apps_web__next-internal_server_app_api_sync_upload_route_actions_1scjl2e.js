module.exports=[47657,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_sync_upload_route_actions_1scjl2e.js.map