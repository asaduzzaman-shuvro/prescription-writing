module.exports=[10691,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_sakura_auth_login_route_actions_1en_o0p.js.map