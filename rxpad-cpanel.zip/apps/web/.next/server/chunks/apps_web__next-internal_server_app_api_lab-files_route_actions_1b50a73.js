module.exports=[96309,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_lab-files_route_actions_1b50a73.js.map