module.exports=[64943,a=>{"use strict";var b=a.i(39304),c=a.i(63561);a.s(["default",0,function(){return(0,b.jsx)("main",{className:"mx-auto max-w-lg p-6",children:(0,b.jsx)(c.PrescriptionLoading,{compact:!0,label:"Loading prescription"})})}])},46558,function(a){a.n(a.i(64943))}];

//# sourceMappingURL=apps_web_src_app_v_%5Btoken%5D_loading_tsx_0el911s._.js.map