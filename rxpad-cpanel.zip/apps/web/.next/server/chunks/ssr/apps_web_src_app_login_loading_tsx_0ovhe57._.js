module.exports=[27034,a=>{"use strict";var b=a.i(13800),c=a.i(63561);a.s(["default",0,function(){return(0,b.jsx)(c.LoginLoading,{})}])},1310,function(a){a.n(a.i(27034))}];

//# sourceMappingURL=apps_web_src_app_login_loading_tsx_0ovhe57._.js.map