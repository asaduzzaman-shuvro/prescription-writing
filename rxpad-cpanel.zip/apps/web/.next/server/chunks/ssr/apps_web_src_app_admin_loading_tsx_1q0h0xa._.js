module.exports=[73437,a=>{"use strict";var b=a.i(39304),c=a.i(63561);a.s(["default",0,function(){return(0,b.jsx)(c.ListPageLoading,{label:"Loading"})}])},17288,function(a){a.n(a.i(73437))}];

//# sourceMappingURL=apps_web_src_app_admin_loading_tsx_1q0h0xa._.js.map