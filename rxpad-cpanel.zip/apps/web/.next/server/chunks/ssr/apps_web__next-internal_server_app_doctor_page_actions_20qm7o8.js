module.exports=[84213,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_doctor_page_actions_20qm7o8.js.map