module.exports=[83010,a=>a.a(async(b,c)=>{try{var d=a.i(62552),e=a.i(26770),f=a.i(60045),g=a.i(77143),h=a.i(89136),i=a.i(26903);a.i(95159);var j=a.i(33383),k=a.i(66680),l=a.i(20267),m=a.i(66746),n=a.i(10961),o=a.i(92782),p=b([e,l,m]);async function q(a){return await (0,n.requireAdmin)(),(0,g.searchProducts)(m.ownerDb,a,15)}async function r(a){let b=await (0,n.requireAdmin)();if(!a.name.trim())return{error:"Name is required"};if(!a.items.length&&!a.advice.length)return{error:"Add medicines or advice"};let c={chiefComplaints:a.chiefComplaints,investigations:a.investigations,diagnoses:a.diagnoses,advice:a.advice,items:a.items},d=a.id??(0,k.randomUUID)();a.id?await m.ownerDb.update(f.s.rxTemplate).set({name:a.name.trim(),specialtyCode:a.specialtyCode,payload:c,isActive:a.isActive,updatedAt:new Date}).where((0,h.eq)(f.s.rxTemplate.id,a.id)):await m.ownerDb.insert(f.s.rxTemplate).values({id:d,tenantId:null,ownerUserId:null,name:a.name.trim(),specialtyCode:a.specialtyCode,payload:c,isActive:a.isActive}),await (0,l.audit)({actorUserId:b.userId,action:a.id?"template.shared.update":"template.shared.create",entity:"rx_template",entityId:d,after:{name:a.name,items:a.items.length}}),(0,i.revalidatePath)("/admin/templates"),(0,j.redirect)("/admin/templates")}[e,l,m]=p.then?(await p)():p,(0,o.ensureServerEntryExports)([q,r]),(0,d.registerServerReference)(q,"40d3d05b90454c54e6799cb302d0a14ca22932c51b",null),(0,d.registerServerReference)(r,"40fc8769349bee96cce3be6bab8fe7c690469be6fb",null),a.s(["findProducts",0,q,"saveSharedTemplate",0,r]),c()}catch(a){c(a)}},!1),81593,a=>a.a(async(b,c)=>{try{var d=a.i(19976),e=a.i(83010),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s([]),c()}catch(a){c(a)}},!1),23761,a=>a.a(async(b,c)=>{try{var d=a.i(81593),e=a.i(19976),f=a.i(83010),g=b([d,e,f]);[d,e,f]=g.then?(await g)():g,a.s(["003b91f4c0c8cae9d1d9359b59d22d4e25d04aa147",()=>e.logout,"40d3d05b90454c54e6799cb302d0a14ca22932c51b",()=>f.findProducts,"40fc8769349bee96cce3be6bab8fe7c690469be6fb",()=>f.saveSharedTemplate,"606dae768b5caf553ca115dc61b14bfde80706e6e1",()=>e.login]),c()}catch(a){c(a)}},!1),77143,a=>{"use strict";let b;var c=a.i(28760);async function d(a){if(void 0!==b)return b;let d=await a.execute(c.sql`select 1 as ok from pg_extension where extname = 'pg_trgm' limit 1`);return b=(Array.isArray(d)?d:d.rows??[]).length>0}async function e(a,b,f=20){let g=b.trim().toLowerCase();if(g.length<2)return[];let h=g.replace(/[\\%_]/g,"\\$&")+"%",i=await d(a),j=i?c.sql`lower(p.brand_name) like ${h}
              or lower(p.generic_text) like ${h}
              or lower(p.brand_name) % ${g}
              or lower(p.generic_text) % ${g}`:c.sql`lower(p.brand_name) like ${h} or lower(p.generic_text) like ${h}`,k=i?c.sql`case when lower(p.brand_name) like ${h} then 3
                  when lower(p.generic_text) like ${h} then 2
                  else greatest(similarity(lower(p.brand_name), ${g}), similarity(lower(p.generic_text), ${g}))
             end`:c.sql`case when lower(p.brand_name) like ${h} then 2 else 1 end`;return await a.execute(c.sql`
    with hits as (
      select p.id, ${k} as score
        from brand_product p
       where p.is_active
         and (${j})
       order by score desc
       limit ${3*f}
    )
    select p.id, p.brand_name as "brandName", p.generic_text as "genericText", p.strength_text as "strengthText",
           f.name as "formName", f.short_label as "formLabel", f.default_route as "defaultRoute",
           f.default_unit as "defaultUnit", c.name as "companyName",
           exists (select 1 from product_ingredient pi join generic g on g.id = pi.generic_id
                    where pi.product_id = p.id and g.is_antibiotic) as "isAntibiotic",
           h.score::float as score
      from hits h
      join brand_product p on p.id = h.id
      left join dosage_form f on f.id = p.form_id
      left join company c on c.id = p.company_id
     order by h.score desc, length(p.brand_name), p.brand_name, p.strength_text
     limit ${f}`)}a.s(["searchProducts",0,e])}];

//# sourceMappingURL=_00cvbct._.js.map