module.exports=[75889,a=>{"use strict";var b=a.i(13800),c=a.i(63561);a.s(["default",0,function(){return(0,b.jsx)(c.ListPageLoading,{label:"Loading chamber"})}])},76473,function(a){a.n(a.i(75889))}];

//# sourceMappingURL=apps_web_src_app_doctor_loading_tsx_0_7xj36._.js.map