module.exports=[53691,a=>{a.v("/_next/static/media/wa-sqlite.215tehs5x7wv3.wasm"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))}];

//# sourceMappingURL=0u-a_%40journeyapps_wa-sqlite_dist_wa-sqlite_wasm_19ocqyk._.js.map