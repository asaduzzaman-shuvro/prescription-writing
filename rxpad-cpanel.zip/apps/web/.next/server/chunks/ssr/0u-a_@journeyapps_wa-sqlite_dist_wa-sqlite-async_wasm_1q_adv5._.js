module.exports=[99567,a=>{a.v("/_next/static/media/wa-sqlite-async.3uz1rde4geynb.wasm"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))}];

//# sourceMappingURL=0u-a_%40journeyapps_wa-sqlite_dist_wa-sqlite-async_wasm_1q_adv5._.js.map