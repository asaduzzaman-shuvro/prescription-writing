module.exports=[55513,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_v_%5Btoken%5D_page_actions_0pocm5n.js.map