module.exports=[88203,a=>{a.v("/_next/static/media/mc-wa-sqlite-async.443omdub3wdcj.wasm"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))}];

//# sourceMappingURL=0u-a_%40journeyapps_wa-sqlite_dist_mc-wa-sqlite-async_wasm_0r9p-2b._.js.map