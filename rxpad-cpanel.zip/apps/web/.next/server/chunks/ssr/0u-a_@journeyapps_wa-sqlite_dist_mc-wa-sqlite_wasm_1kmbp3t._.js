module.exports=[81390,a=>{a.v("/_next/static/media/mc-wa-sqlite.1b6n42069fkm5.wasm"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))}];

//# sourceMappingURL=0u-a_%40journeyapps_wa-sqlite_dist_mc-wa-sqlite_wasm_1kmbp3t._.js.map