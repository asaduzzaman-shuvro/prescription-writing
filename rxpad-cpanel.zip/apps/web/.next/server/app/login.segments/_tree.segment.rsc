:HL["/_next/static/chunks/3n_4a72kzh51t.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4188,"slots":{"children":{"name":"login","param":null,"prefetchHints":4196,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"66rqnBQSp_Il0mtAqks3X"}
