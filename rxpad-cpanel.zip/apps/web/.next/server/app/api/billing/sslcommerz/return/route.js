var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/billing/sslcommerz/return/route.js")
R.c("server/chunks/[root-of-the-server]__0-qj5fs._.js")
R.c("server/chunks/[root-of-the-server]__1aw_5p0._.js")
R.c("server/chunks/10e5_next_16cc-o-._.js")
R.c("server/chunks/0gy1__next-internal_server_app_api_billing_sslcommerz_return_route_actions_1pheu4z.js")
R.m(45090)
module.exports=R.m(45090).exports
