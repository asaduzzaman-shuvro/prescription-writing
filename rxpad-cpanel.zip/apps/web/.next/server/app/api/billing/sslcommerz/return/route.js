var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/billing/sslcommerz/return/route.js")
R.c("server/chunks/[root-of-the-server]__0v304ma._.js")
R.c("server/chunks/[root-of-the-server]__0zaybq4._.js")
R.c("server/chunks/1728_next_0-lu239._.js")
R.c("server/chunks/0gy1__next-internal_server_app_api_billing_sslcommerz_return_route_actions_1pheu4z.js")
R.m(41802)
module.exports=R.m(41802).exports
