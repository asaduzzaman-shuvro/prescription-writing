var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0ufg8_e._.js")
R.c("server/chunks/10e5_next_0lbex6h._.js")
R.c("server/chunks/_0-wkxch._.js")
R.c("server/chunks/[root-of-the-server]__1aw_5p0._.js")
R.c("server/chunks/10e5_next_16cc-o-._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_auth_logout_route_actions_1e3_z08.js")
R.m(15381)
module.exports=R.m(15381).exports
