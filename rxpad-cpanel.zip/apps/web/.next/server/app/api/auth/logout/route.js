var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__07uls0l._.js")
R.c("server/chunks/1728_next_19ei58_._.js")
R.c("server/chunks/_0voe7ym._.js")
R.c("server/chunks/[root-of-the-server]__0zaybq4._.js")
R.c("server/chunks/1728_next_0-lu239._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_auth_logout_route_actions_1e3_z08.js")
R.m(63104)
module.exports=R.m(63104).exports
