:HL["/_next/static/chunks/3n2sffd71fq9w.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4188,"slots":{"children":{"name":"login","param":null,"prefetchHints":4196,"slots":{"children":{"name":"reset","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"kh-LgRWrGg_36oqK-bWBv"}
