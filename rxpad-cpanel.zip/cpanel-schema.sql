-- Tables for shared cPanel. No pg_trgm indexes, no extra roles, no PowerSync.

-- Run once: psql -h 127.0.0.1 -p 5432 -U sakuraph_SakuraPharma -d sakuraph_prescription -v ON_ERROR_STOP=1 -f cpanel-schema.sql

BEGIN;

CREATE TYPE "public"."aware_group" AS ENUM('access', 'watch', 'reserve');

CREATE TYPE "public"."interaction_severity" AS ENUM('minor', 'moderate', 'major', 'contraindicated');

CREATE TYPE "public"."medicine_system" AS ENUM('allopathic', 'herbal', 'ayurvedic', 'unani', 'homeopathic');

CREATE TYPE "public"."encounter_status" AS ENUM('waiting', 'in_progress', 'done', 'cancelled');

CREATE TYPE "public"."platform_role" AS ENUM('super_admin', 'data_editor');

CREATE TYPE "public"."prescription_status" AS ENUM('draft', 'final');

CREATE TYPE "public"."sex" AS ENUM('male', 'female', 'other');

CREATE TYPE "public"."tenant_kind" AS ENUM('solo', 'clinic');

CREATE TYPE "public"."tenant_role" AS ENUM('clinic_admin', 'doctor', 'assistant');

CREATE TYPE "public"."tenant_status" AS ENUM('pending', 'active', 'suspended');

CREATE TABLE "advice_snippet" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"text_bn" text NOT NULL,
	"text_en" text,
	"category" text
);

CREATE TABLE "brand_product" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"brand_name" text NOT NULL,
	"form_id" uuid,
	"company_id" uuid,
	"strength_text" text,
	"dar_number" text,
	"medicine_system" "medicine_system" DEFAULT 'allopathic' NOT NULL,
	"generic_text" text DEFAULT '' NOT NULL,
	"discontinued_at" timestamp with time zone,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "company" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "complaint" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"name" text NOT NULL,
	"name_bn" text
);

CREATE TABLE "diagnosis" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"name" text NOT NULL,
	"icd10" text,
	"icd11" text
);

CREATE TABLE "dosage_form" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"short_label" text,
	"default_route" text,
	"default_unit" text,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "drug_class" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "generic" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"synonyms" text[] DEFAULT '{}'::text[] NOT NULL,
	"is_antibiotic" boolean DEFAULT false NOT NULL,
	"aware_group" "aware_group",
	"pregnancy_category" text,
	"paed_max_mg_per_kg_day" numeric(10, 3),
	"adult_max_mg_per_day" numeric(10, 3),
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "generic_drug_class" (
	"generic_id" uuid NOT NULL,
	"drug_class_id" uuid NOT NULL,
	CONSTRAINT "generic_drug_class_generic_id_drug_class_id_pk" PRIMARY KEY("generic_id","drug_class_id")
);

CREATE TABLE "generic_interaction" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"generic_a" uuid NOT NULL,
	"generic_b" uuid NOT NULL,
	"severity" "interaction_severity" NOT NULL,
	"effect" text NOT NULL,
	"management" text,
	"reviewed_by" text,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	CONSTRAINT "generic_interaction_order" CHECK ("generic_interaction"."generic_a" < "generic_interaction"."generic_b")
);

CREATE TABLE "generic_monograph" (
	"generic_id" uuid PRIMARY KEY NOT NULL,
	"indications" text,
	"dosage" text,
	"administration" text,
	"contraindications" text,
	"side_effects" text,
	"interactions" text,
	"pregnancy_lactation" text,
	"precautions" text,
	"paediatric_use" text,
	"format" text DEFAULT 'text' NOT NULL,
	"source" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "instruction_snippet" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"text_bn" text NOT NULL,
	"text_en" text
);

CREATE TABLE "investigation" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"name" text NOT NULL,
	"category" text
);

CREATE TABLE "product_ingredient" (
	"product_id" uuid NOT NULL,
	"position" smallint NOT NULL,
	"generic_id" uuid NOT NULL,
	"strength_value" numeric(14, 4),
	"strength_unit" text,
	"basis" text,
	CONSTRAINT "product_ingredient_product_id_position_pk" PRIMARY KEY("product_id","position")
);

CREATE TABLE "product_pack" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"product_id" uuid NOT NULL,
	"description" text NOT NULL,
	"pack_size" text,
	"mrp" numeric(12, 2),
	"price_date" date,
	"price_source" text NOT NULL,
	"govt_fixed" boolean DEFAULT false NOT NULL
);

CREATE TABLE "specialty" (
	"code" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"name_bn" text
);

CREATE TABLE "specialty_template" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text NOT NULL,
	"name" text NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"schema" text NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid
);

CREATE TABLE "app_user" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"phone" text,
	"name" text NOT NULL,
	"password_hash" text NOT NULL,
	"platform_role" "platform_role",
	"disabled" boolean DEFAULT false NOT NULL,
	"last_login_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "audit_log" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"at" timestamp with time zone DEFAULT now() NOT NULL,
	"actor_user_id" uuid,
	"tenant_id" uuid,
	"action" text NOT NULL,
	"entity" text NOT NULL,
	"entity_id" text,
	"before" jsonb,
	"after" jsonb,
	"ip" text
);

CREATE TABLE "chamber" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"doctor_user_id" uuid,
	"name" text NOT NULL,
	"address" text NOT NULL,
	"phone" text,
	"hours" text,
	"print_settings" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "doctor_favorite" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"product_id" uuid NOT NULL,
	"default_shortcut" text,
	"use_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "doctor_profile" (
	"user_id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"name_en" text NOT NULL,
	"name_bn" text,
	"degrees_en" text[] DEFAULT '{}'::text[] NOT NULL,
	"degrees_bn" text[] DEFAULT '{}'::text[] NOT NULL,
	"designation" text,
	"institution" text,
	"specialty_code" text DEFAULT 'general' NOT NULL,
	"specialty_label" text,
	"bmdc_number" text NOT NULL,
	"bmdc_expiry" date,
	"bmdc_verified_at" timestamp with time zone,
	"bmdc_verified_by" uuid,
	"signature_data_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "encounter" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"patient_id" uuid NOT NULL,
	"doctor_user_id" uuid NOT NULL,
	"chamber_id" uuid,
	"visit_date" date NOT NULL,
	"serial_no" integer,
	"status" "encounter_status" DEFAULT 'waiting' NOT NULL,
	"specialty_code" text DEFAULT 'general' NOT NULL,
	"template_id" uuid,
	"vitals" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"exam_findings" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"fee" integer,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "import_job" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"kind" text NOT NULL,
	"filename" text NOT NULL,
	"source" text NOT NULL,
	"status" text DEFAULT 'previewed' NOT NULL,
	"summary" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"committed_at" timestamp with time zone
);

CREATE TABLE "membership" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "tenant_role" NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "patient" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"code" text,
	"name" text NOT NULL,
	"dob" date,
	"dob_estimated" boolean DEFAULT false NOT NULL,
	"sex" "sex",
	"mobile" text,
	"address" text,
	"nid" text,
	"brn" text,
	"health_id" text,
	"allergies" text[] DEFAULT '{}'::text[] NOT NULL,
	"notes" text,
	"consent_at" timestamp with time zone,
	"guardian_name" text,
	"created_by" uuid,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "prescription" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"encounter_id" uuid NOT NULL,
	"patient_id" uuid NOT NULL,
	"doctor_user_id" uuid NOT NULL,
	"chamber_id" uuid,
	"version" integer DEFAULT 1 NOT NULL,
	"supersedes_id" uuid,
	"status" "prescription_status" DEFAULT 'draft' NOT NULL,
	"doc" jsonb NOT NULL,
	"finalized_at" timestamp with time zone,
	"verify_token" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "prescription_item" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"prescription_id" uuid NOT NULL,
	"position" integer NOT NULL,
	"product_id" uuid,
	"brand_name" text NOT NULL,
	"generic_name" text,
	"instruction" text NOT NULL
);

CREATE TABLE "rx_template" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid,
	"owner_user_id" uuid,
	"specialty_code" text,
	"name" text NOT NULL,
	"payload" jsonb NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "tenant" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"kind" "tenant_kind" DEFAULT 'solo' NOT NULL,
	"status" "tenant_status" DEFAULT 'pending' NOT NULL,
	"plan" text DEFAULT 'trial' NOT NULL,
	"patient_seq" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE "advice_snippet" ADD CONSTRAINT "advice_snippet_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "brand_product" ADD CONSTRAINT "brand_product_form_id_dosage_form_id_fk" FOREIGN KEY ("form_id") REFERENCES "public"."dosage_form"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "brand_product" ADD CONSTRAINT "brand_product_company_id_company_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."company"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "complaint" ADD CONSTRAINT "complaint_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "diagnosis" ADD CONSTRAINT "diagnosis_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "generic_drug_class" ADD CONSTRAINT "generic_drug_class_generic_id_generic_id_fk" FOREIGN KEY ("generic_id") REFERENCES "public"."generic"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "generic_drug_class" ADD CONSTRAINT "generic_drug_class_drug_class_id_drug_class_id_fk" FOREIGN KEY ("drug_class_id") REFERENCES "public"."drug_class"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "generic_interaction" ADD CONSTRAINT "generic_interaction_generic_a_generic_id_fk" FOREIGN KEY ("generic_a") REFERENCES "public"."generic"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "generic_interaction" ADD CONSTRAINT "generic_interaction_generic_b_generic_id_fk" FOREIGN KEY ("generic_b") REFERENCES "public"."generic"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "generic_monograph" ADD CONSTRAINT "generic_monograph_generic_id_generic_id_fk" FOREIGN KEY ("generic_id") REFERENCES "public"."generic"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "instruction_snippet" ADD CONSTRAINT "instruction_snippet_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "investigation" ADD CONSTRAINT "investigation_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "product_ingredient" ADD CONSTRAINT "product_ingredient_product_id_brand_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."brand_product"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "product_ingredient" ADD CONSTRAINT "product_ingredient_generic_id_generic_id_fk" FOREIGN KEY ("generic_id") REFERENCES "public"."generic"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "product_pack" ADD CONSTRAINT "product_pack_product_id_brand_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."brand_product"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "specialty_template" ADD CONSTRAINT "specialty_template_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "chamber" ADD CONSTRAINT "chamber_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "chamber" ADD CONSTRAINT "chamber_doctor_user_id_app_user_id_fk" FOREIGN KEY ("doctor_user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_favorite" ADD CONSTRAINT "doctor_favorite_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_favorite" ADD CONSTRAINT "doctor_favorite_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_favorite" ADD CONSTRAINT "doctor_favorite_product_id_brand_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."brand_product"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_profile" ADD CONSTRAINT "doctor_profile_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_profile" ADD CONSTRAINT "doctor_profile_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_profile" ADD CONSTRAINT "doctor_profile_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

ALTER TABLE "doctor_profile" ADD CONSTRAINT "doctor_profile_bmdc_verified_by_app_user_id_fk" FOREIGN KEY ("bmdc_verified_by") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "encounter" ADD CONSTRAINT "encounter_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "encounter" ADD CONSTRAINT "encounter_patient_id_patient_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patient"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "encounter" ADD CONSTRAINT "encounter_doctor_user_id_app_user_id_fk" FOREIGN KEY ("doctor_user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "encounter" ADD CONSTRAINT "encounter_chamber_id_chamber_id_fk" FOREIGN KEY ("chamber_id") REFERENCES "public"."chamber"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "encounter" ADD CONSTRAINT "encounter_template_id_specialty_template_id_fk" FOREIGN KEY ("template_id") REFERENCES "public"."specialty_template"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "membership" ADD CONSTRAINT "membership_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "membership" ADD CONSTRAINT "membership_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "patient" ADD CONSTRAINT "patient_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription" ADD CONSTRAINT "prescription_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription" ADD CONSTRAINT "prescription_encounter_id_encounter_id_fk" FOREIGN KEY ("encounter_id") REFERENCES "public"."encounter"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription" ADD CONSTRAINT "prescription_patient_id_patient_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patient"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription" ADD CONSTRAINT "prescription_doctor_user_id_app_user_id_fk" FOREIGN KEY ("doctor_user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription" ADD CONSTRAINT "prescription_chamber_id_chamber_id_fk" FOREIGN KEY ("chamber_id") REFERENCES "public"."chamber"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription_item" ADD CONSTRAINT "prescription_item_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription_item" ADD CONSTRAINT "prescription_item_prescription_id_prescription_id_fk" FOREIGN KEY ("prescription_id") REFERENCES "public"."prescription"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "prescription_item" ADD CONSTRAINT "prescription_item_product_id_brand_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."brand_product"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "rx_template" ADD CONSTRAINT "rx_template_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "rx_template" ADD CONSTRAINT "rx_template_owner_user_id_app_user_id_fk" FOREIGN KEY ("owner_user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "rx_template" ADD CONSTRAINT "rx_template_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;

CREATE UNIQUE INDEX "brand_product_dar_uq" ON "brand_product" USING btree ("dar_number");

CREATE INDEX "brand_product_brand_prefix" ON "brand_product" USING btree (lower("brand_name") text_pattern_ops);

CREATE INDEX "brand_product_company_idx" ON "brand_product" USING btree ("company_id");

CREATE UNIQUE INDEX "company_name_uq" ON "company" USING btree (lower("name"));

CREATE UNIQUE INDEX "dosage_form_name_uq" ON "dosage_form" USING btree (lower("name"));

CREATE UNIQUE INDEX "drug_class_name_uq" ON "drug_class" USING btree (lower("name"));

CREATE UNIQUE INDEX "generic_name_uq" ON "generic" USING btree (lower("name"));

CREATE UNIQUE INDEX "generic_interaction_pair_uq" ON "generic_interaction" USING btree ("generic_a","generic_b");

CREATE INDEX "product_ingredient_generic_idx" ON "product_ingredient" USING btree ("generic_id");

CREATE INDEX "product_pack_product_idx" ON "product_pack" USING btree ("product_id");

CREATE UNIQUE INDEX "specialty_template_uq" ON "specialty_template" USING btree ("specialty_code","name","version");

CREATE UNIQUE INDEX "app_user_email_uq" ON "app_user" USING btree (lower("email"));

CREATE INDEX "audit_log_tenant_at_idx" ON "audit_log" USING btree ("tenant_id","at");

CREATE INDEX "audit_log_entity_idx" ON "audit_log" USING btree ("entity","entity_id");

CREATE INDEX "chamber_tenant_idx" ON "chamber" USING btree ("tenant_id");

CREATE UNIQUE INDEX "doctor_favorite_uq" ON "doctor_favorite" USING btree ("user_id","product_id");

CREATE UNIQUE INDEX "doctor_profile_bmdc_uq" ON "doctor_profile" USING btree (upper("bmdc_number"));

CREATE INDEX "encounter_tenant_date_idx" ON "encounter" USING btree ("tenant_id","visit_date");

CREATE INDEX "encounter_patient_idx" ON "encounter" USING btree ("patient_id");

CREATE UNIQUE INDEX "membership_uq" ON "membership" USING btree ("tenant_id","user_id");

CREATE INDEX "patient_tenant_mobile_idx" ON "patient" USING btree ("tenant_id","mobile");

CREATE UNIQUE INDEX "patient_tenant_code_uq" ON "patient" USING btree ("tenant_id","code");

CREATE INDEX "prescription_patient_idx" ON "prescription" USING btree ("patient_id");

CREATE INDEX "prescription_tenant_created_idx" ON "prescription" USING btree ("tenant_id","created_at");

CREATE UNIQUE INDEX "prescription_verify_uq" ON "prescription" USING btree ("verify_token");

CREATE INDEX "prescription_item_rx_idx" ON "prescription_item" USING btree ("prescription_id");

CREATE INDEX "prescription_item_product_idx" ON "prescription_item" USING btree ("product_id");

CREATE INDEX "rx_template_tenant_idx" ON "rx_template" USING btree ("tenant_id");

CREATE OR REPLACE FUNCTION app_tenant_id() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.tenant_id', true), '')::uuid $$;

ALTER TABLE tenant ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON tenant USING (id = app_tenant_id());

ALTER TABLE rx_template ENABLE ROW LEVEL SECURITY;

-- Platform-shared templates (tenant_id IS NULL) are readable by everyone but writable by no clinic.
CREATE POLICY rx_template_read ON rx_template FOR SELECT USING (tenant_id IS NULL OR tenant_id = app_tenant_id());

CREATE POLICY rx_template_write ON rx_template FOR ALL USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['membership','doctor_profile','chamber','patient','encounter','prescription',
                           'prescription_item','doctor_favorite','audit_log']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id())', t);
  END LOOP;
END $$;

CREATE TYPE "public"."appointment_status" AS ENUM('booked', 'checked_in', 'cancelled', 'no_show');

CREATE TABLE "appointment" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"chamber_id" uuid,
	"doctor_user_id" uuid NOT NULL,
	"patient_id" uuid,
	"name" text NOT NULL,
	"mobile" text,
	"appt_date" date NOT NULL,
	"serial_no" integer NOT NULL,
	"status" "appointment_status" DEFAULT 'booked' NOT NULL,
	"encounter_id" uuid,
	"note" text,
	"source" text DEFAULT 'chamber' NOT NULL,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "sms_log" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"prescription_id" uuid,
	"to_number" text NOT NULL,
	"body" text NOT NULL,
	"provider" text NOT NULL,
	"status" text NOT NULL,
	"provider_ref" text,
	"error" text,
	"segments" integer DEFAULT 1 NOT NULL,
	"sent_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE "subscription_payment" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"plan" text NOT NULL,
	"months" integer NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"method" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"tran_id" text NOT NULL,
	"gateway_ref" text,
	"gateway_payload" jsonb,
	"paid_at" timestamp with time zone,
	"recorded_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE "tenant" ADD COLUMN "plan_expires_at" date;

ALTER TABLE "tenant" ADD COLUMN "sms_credits" integer DEFAULT 0 NOT NULL;

ALTER TABLE "tenant" ADD COLUMN "display_token" text;

ALTER TABLE "appointment" ADD CONSTRAINT "appointment_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "appointment" ADD CONSTRAINT "appointment_chamber_id_chamber_id_fk" FOREIGN KEY ("chamber_id") REFERENCES "public"."chamber"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "appointment" ADD CONSTRAINT "appointment_doctor_user_id_app_user_id_fk" FOREIGN KEY ("doctor_user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "appointment" ADD CONSTRAINT "appointment_patient_id_patient_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patient"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "sms_log" ADD CONSTRAINT "sms_log_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "sms_log" ADD CONSTRAINT "sms_log_prescription_id_prescription_id_fk" FOREIGN KEY ("prescription_id") REFERENCES "public"."prescription"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "subscription_payment" ADD CONSTRAINT "subscription_payment_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

CREATE INDEX "appointment_tenant_date_idx" ON "appointment" USING btree ("tenant_id","appt_date");

CREATE INDEX "sms_log_tenant_idx" ON "sms_log" USING btree ("tenant_id","created_at");

CREATE UNIQUE INDEX "subscription_payment_tran_uq" ON "subscription_payment" USING btree ("tran_id");

CREATE INDEX "subscription_payment_tenant_idx" ON "subscription_payment" USING btree ("tenant_id");

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['appointment','sms_log','subscription_payment']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id())', t);
  END LOOP;
END $$;

ALTER TABLE "tenant" DROP COLUMN "display_token";

ALTER TABLE "chamber" ADD COLUMN "schedule" jsonb DEFAULT '[]'::jsonb NOT NULL;

ALTER TABLE "chamber" ADD COLUMN "serial_phone" text;

ALTER TABLE "chamber" ADD COLUMN "footer_text" text;

ALTER TABLE "chamber" ADD COLUMN "logo_data_url" text;

ALTER TABLE "patient" ADD COLUMN "birth_weight_kg" real;

ALTER TABLE "patient" ADD COLUMN "gestational_age_weeks" integer;

CREATE TYPE "public"."visit_type" AS ENUM('new', 'followup', 'report');

ALTER TABLE "chamber" ADD COLUMN "free_report_days" integer;

ALTER TABLE "encounter" ADD COLUMN "visit_type" "visit_type";

CREATE TABLE "lab_report" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"patient_id" uuid NOT NULL,
	"encounter_id" uuid,
	"report_date" date NOT NULL,
	"lab_name" text,
	"panel" text NOT NULL,
	"title" text NOT NULL,
	"results" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"conclusion" text,
	"created_by" uuid,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE "lab_report" ADD CONSTRAINT "lab_report_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "lab_report" ADD CONSTRAINT "lab_report_patient_id_patient_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patient"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "lab_report" ADD CONSTRAINT "lab_report_encounter_id_encounter_id_fk" FOREIGN KEY ("encounter_id") REFERENCES "public"."encounter"("id") ON DELETE no action ON UPDATE no action;

CREATE INDEX "lab_report_patient_idx" ON "lab_report" USING btree ("patient_id","report_date");

CREATE INDEX "lab_report_encounter_idx" ON "lab_report" USING btree ("encounter_id");

ALTER TABLE lab_report ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON lab_report USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

CREATE TABLE "lab_file" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"patient_id" uuid NOT NULL,
	"lab_report_id" uuid NOT NULL,
	"content_type" text NOT NULL,
	"size_bytes" integer NOT NULL,
	"sha256" text NOT NULL,
	"data" "bytea" NOT NULL,
	"created_by" uuid,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE "lab_report" ADD COLUMN "files" jsonb DEFAULT '[]'::jsonb NOT NULL;

ALTER TABLE "patient" ADD COLUMN "report_files_consent_at" timestamp with time zone;

ALTER TABLE "lab_file" ADD CONSTRAINT "lab_file_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "lab_file" ADD CONSTRAINT "lab_file_patient_id_patient_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patient"("id") ON DELETE no action ON UPDATE no action;

CREATE INDEX "lab_file_report_idx" ON "lab_file" USING btree ("lab_report_id");

ALTER TABLE lab_file ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON lab_file USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

CREATE TABLE "lab_panel" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid,
	"key" text NOT NULL,
	"name" text,
	"department" text,
	"sort_order" integer,
	"is_active" boolean DEFAULT true NOT NULL,
	"spec" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"source" text DEFAULT 'clinic' NOT NULL,
	"updated_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "lab_panel_platform_complete" CHECK ("lab_panel"."tenant_id" is not null or "lab_panel"."name" is not null)
);

CREATE TABLE "lab_profile" (
	"id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"lab_name" text,
	"address" text,
	"phone" text,
	"logo_data_url" text,
	"signatories" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"footer_text" text,
	"print_settings" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "lab_profile_tenantId_unique" UNIQUE("tenant_id")
);

CREATE TABLE "lab_test" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid,
	"code" text NOT NULL,
	"name" text,
	"short" text,
	"unit" text,
	"kind" text,
	"department" text,
	"sort_order" integer,
	"is_active" boolean DEFAULT true NOT NULL,
	"spec" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"source" text DEFAULT 'clinic' NOT NULL,
	"updated_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "lab_test_platform_complete" CHECK ("lab_test"."tenant_id" is not null or ("lab_test"."name" is not null and "lab_test"."short" is not null and "lab_test"."kind" is not null))
);

ALTER TABLE "lab_report" ADD COLUMN "source" text DEFAULT 'external' NOT NULL;

ALTER TABLE "lab_report" ADD COLUMN "request_id" uuid;

ALTER TABLE "lab_report" ADD COLUMN "lab_no" text;

ALTER TABLE "lab_report" ADD COLUMN "department" text;

ALTER TABLE "lab_report" ADD COLUMN "specimen" text;

ALTER TABLE "lab_report" ADD COLUMN "collected_at" timestamp with time zone;

ALTER TABLE "lab_report" ADD COLUMN "referred_by" text;

ALTER TABLE "lab_report" ADD COLUMN "prepared_by_name" text;

ALTER TABLE "lab_report" ADD COLUMN "comment" text;

ALTER TABLE "tenant" ADD COLUMN "lab_seq" integer DEFAULT 0 NOT NULL;

ALTER TABLE "lab_panel" ADD CONSTRAINT "lab_panel_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "lab_profile" ADD CONSTRAINT "lab_profile_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "lab_test" ADD CONSTRAINT "lab_test_tenant_id_tenant_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenant"("id") ON DELETE no action ON UPDATE no action;

CREATE UNIQUE INDEX "lab_panel_platform_key_uq" ON "lab_panel" USING btree ("key") WHERE "lab_panel"."tenant_id" is null;

CREATE UNIQUE INDEX "lab_panel_tenant_key_uq" ON "lab_panel" USING btree ("tenant_id","key") WHERE "lab_panel"."tenant_id" is not null;

CREATE UNIQUE INDEX "lab_test_platform_code_uq" ON "lab_test" USING btree ("code") WHERE "lab_test"."tenant_id" is null;

CREATE UNIQUE INDEX "lab_test_tenant_code_uq" ON "lab_test" USING btree ("tenant_id","code") WHERE "lab_test"."tenant_id" is not null;

CREATE INDEX "lab_report_request_idx" ON "lab_report" USING btree ("request_id");

ALTER TABLE lab_test ENABLE ROW LEVEL SECURITY;

CREATE POLICY lab_test_read ON lab_test FOR SELECT USING (tenant_id IS NULL OR tenant_id = app_tenant_id());

CREATE POLICY lab_test_write ON lab_test FOR ALL USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

ALTER TABLE lab_panel ENABLE ROW LEVEL SECURITY;

CREATE POLICY lab_panel_read ON lab_panel FOR SELECT USING (tenant_id IS NULL OR tenant_id = app_tenant_id());

CREATE POLICY lab_panel_write ON lab_panel FOR ALL USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

ALTER TABLE lab_profile ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON lab_profile USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id());

ALTER TABLE "patient" ADD COLUMN "pregnancy_status" text;

ALTER TABLE "patient" ADD CONSTRAINT "patient_pregnancy_status_check" CHECK (
  "pregnancy_status" IS NULL OR "pregnancy_status" IN ('none', 'pregnant', 'lactating', 'both')
);

ALTER TABLE "app_user" ADD COLUMN "totp_secret" text;

ALTER TABLE "app_user" ADD COLUMN "totp_enabled_at" timestamp with time zone;

ALTER TABLE "lab_report" ADD COLUMN "verified_by_name" text;

ALTER TABLE "lab_report" ADD COLUMN "verified_at" timestamp with time zone;

CREATE TABLE IF NOT EXISTS "password_reset" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "user_id" uuid NOT NULL REFERENCES "app_user"("id"),
  "token_hash" text NOT NULL,
  "expires_at" timestamp with time zone NOT NULL,
  "used_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "password_reset_user_idx" ON "password_reset" ("user_id");

CREATE UNIQUE INDEX IF NOT EXISTS "password_reset_token_uq" ON "password_reset" ("token_hash");

CREATE TABLE "history_item" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"specialty_code" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"source" text NOT NULL,
	"source_ref" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_by" uuid,
	"name" text NOT NULL,
	"category" text
);

ALTER TABLE "history_item" ADD CONSTRAINT "history_item_specialty_code_specialty_code_fk" FOREIGN KEY ("specialty_code") REFERENCES "public"."specialty"("code") ON DELETE no action ON UPDATE no action;


insert into specialty (code, name, name_bn) values
  ('general', 'General Practice', 'সাধারণ চিকিৎসা'),
  ('ent', 'ENT (Otorhinolaryngology)', 'নাক, কান ও গলা'),
  ('ophthalmology', 'Ophthalmology', 'চক্ষু'),
  ('vascular', 'Vascular surgery', 'ভাসকুলার সার্জারি')
on conflict (code) do nothing;



insert into complaint (specialty_code, sort_order, source, name, name_bn)
select specialty_code, sort_order, source, name, name_bn from (values
  (null, 0, 'rx-curated', 'Fever', 'জ্বর'),
  (null, 1, 'rx-curated', 'Cough', 'কাশি'),
  (null, 2, 'rx-curated', 'Headache', 'মাথাব্যথা'),
  (null, 3, 'rx-curated', 'Body ache', 'শরীর ব্যথা'),
  (null, 4, 'rx-curated', 'Abdominal pain', 'পেট ব্যথা'),
  (null, 5, 'rx-curated', 'Burning epigastric pain', 'বুক জ্বালাপোড়া'),
  (null, 6, 'rx-curated', 'Loose motion', 'পাতলা পায়খানা'),
  (null, 7, 'rx-curated', 'Vomiting', 'বমি'),
  (null, 8, 'rx-curated', 'Nausea', 'বমি বমি ভাব'),
  (null, 9, 'rx-curated', 'Constipation', 'কোষ্ঠকাঠিন্য'),
  (null, 10, 'rx-curated', 'Weakness', 'দুর্বলতা'),
  (null, 11, 'rx-curated', 'Dizziness', 'মাথা ঘোরা'),
  (null, 12, 'rx-curated', 'Chest pain', 'বুকে ব্যথা'),
  (null, 13, 'rx-curated', 'Shortness of breath', 'শ্বাসকষ্ট'),
  (null, 14, 'rx-curated', 'Palpitation', 'বুক ধড়ফড়'),
  (null, 15, 'rx-curated', 'Joint pain', 'গিঁটে ব্যথা'),
  (null, 16, 'rx-curated', 'Back pain', 'কোমর ব্যথা'),
  (null, 17, 'rx-curated', 'Itching', 'চুলকানি'),
  (null, 18, 'rx-curated', 'Skin rash', 'চামড়ায় র‍্যাশ'),
  (null, 19, 'rx-curated', 'Burning micturition', 'প্রস্রাবে জ্বালাপোড়া'),
  (null, 20, 'rx-curated', 'Frequent urination', 'ঘন ঘন প্রস্রাব'),
  (null, 21, 'rx-curated', 'Loss of appetite', 'ক্ষুধামন্দা'),
  (null, 22, 'rx-curated', 'Sleep disturbance', 'ঘুমের সমস্যা'),
  (null, 23, 'rx-curated', 'Sore throat', 'গলা ব্যথা'),
  (null, 24, 'rx-curated', 'Runny nose', 'নাক দিয়ে পানি পড়া'),
  ('ent', 25, 'rx-curated', 'Ear discharge', 'কান দিয়ে পুঁজ/পানি পড়া'),
  ('ent', 26, 'rx-curated', 'Earache', 'কান ব্যথা'),
  ('ent', 27, 'rx-curated', 'Hearing loss', 'কানে কম শোনা'),
  ('ent', 28, 'rx-curated', 'Tinnitus', 'কানে শব্দ হওয়া'),
  ('ent', 29, 'rx-curated', 'Blocked ear', 'কান বন্ধ লাগা'),
  ('ent', 30, 'rx-curated', 'Itching in ear', 'কান চুলকানো'),
  ('ent', 31, 'rx-curated', 'Vertigo', 'মাথা ঘোরা (ঘূর্ণন)'),
  ('ent', 32, 'rx-curated', 'Nasal obstruction', 'নাক বন্ধ'),
  ('ent', 33, 'rx-curated', 'Sneezing', 'হাঁচি'),
  ('ent', 34, 'rx-curated', 'Nasal discharge', 'নাক দিয়ে পানি/সর্দি পড়া'),
  ('ent', 35, 'rx-curated', 'Epistaxis', 'নাক দিয়ে রক্ত পড়া'),
  ('ent', 36, 'rx-curated', 'Loss of smell', 'ঘ্রাণ না পাওয়া'),
  ('ent', 37, 'rx-curated', 'Facial pain / heaviness', 'মুখমণ্ডলে ব্যথা/ভার'),
  ('ent', 38, 'rx-curated', 'Snoring', 'নাক ডাকা'),
  ('ent', 39, 'rx-curated', 'Mouth breathing', 'মুখ দিয়ে শ্বাস'),
  ('ent', 40, 'rx-curated', 'Odynophagia', 'ঢোক গিলতে ব্যথা'),
  ('ent', 41, 'rx-curated', 'Dysphagia', 'ঢোক গিলতে কষ্ট'),
  ('ent', 42, 'rx-curated', 'Hoarseness of voice', 'গলা বসে যাওয়া'),
  ('ent', 43, 'rx-curated', 'Neck swelling', 'গলা ফুলে যাওয়া'),
  ('ent', 44, 'rx-curated', 'Foreign body', 'বাইরের বস্তু ঢুকে যাওয়া'),
  ('ophthalmology', 45, 'rx-curated', 'Blurring of vision', 'চোখে ঝাপসা দেখা'),
  ('ophthalmology', 46, 'rx-curated', 'Redness of eye', 'চোখ লাল হওয়া'),
  ('ophthalmology', 47, 'rx-curated', 'Watering of eye', 'চোখ দিয়ে পানি পড়া'),
  ('ophthalmology', 48, 'rx-curated', 'Eye pain', 'চোখে ব্যথা'),
  ('ophthalmology', 49, 'rx-curated', 'Itching of eye', 'চোখ চুলকানো'),
  ('ophthalmology', 50, 'rx-curated', 'Foreign body sensation', 'চোখে কিছু পড়েছে মনে হওয়া'),
  ('ophthalmology', 51, 'rx-curated', 'Eye discharge', 'চোখে পিচুটি'),
  ('ophthalmology', 52, 'rx-curated', 'Swelling of eyelid', 'চোখের পাতা ফোলা'),
  ('ophthalmology', 53, 'rx-curated', 'Double vision', 'একটি জিনিস দুটি দেখা'),
  ('ophthalmology', 54, 'rx-curated', 'Difficulty in near vision', 'কাছের জিনিস দেখতে অসুবিধা'),
  ('ophthalmology', 55, 'rx-curated', 'Floaters', 'চোখের সামনে কালো কিছু ভাসা'),
  ('ophthalmology', 56, 'rx-curated', 'ROP screening', 'আরওপি স্ক্রিনিং'),
  ('vascular', 57, 'rx-curated', 'Pain, swelling and redness of leg', 'পায়ে ব্যথা, ফোলা ও লাল হওয়া'),
  ('vascular', 58, 'rx-curated', 'Ulcer in leg', 'পায়ে ঘা'),
  ('vascular', 59, 'rx-curated', 'Tightness of calf/thigh', 'পায়ের গোছা/উরু টানটান লাগা'),
  ('vascular', 60, 'rx-curated', 'Blisters present', 'ফোসকা'),
  ('vascular', 61, 'rx-curated', 'Leg pain on walking (claudication)', 'হাঁটলে পায়ে ব্যথা'),
  ('vascular', 62, 'rx-curated', 'Swollen veins in leg', 'পায়ের রগ ফুলে যাওয়া'),
  ('vascular', 63, 'rx-curated', 'Discolouration of leg', 'পায়ের রং পরিবর্তন'),
  ('vascular', 64, 'rx-curated', 'Cold, numb foot', 'পা ঠান্ডা ও অবশ লাগা'),
  ('vascular', 65, 'rx-curated', 'Leg heaviness', 'পা ভারী লাগা')
) as v(specialty_code, sort_order, source, name, name_bn)
where not exists (select 1 from complaint);



insert into history_item (specialty_code, sort_order, source, name, category)
select specialty_code, sort_order, source, name, category from (values
  (null, 0, 'rx-curated', 'H/O DM', 'Past'),
  (null, 1, 'rx-curated', 'H/O HTN', 'Past'),
  (null, 2, 'rx-curated', 'H/O IHD', 'Past'),
  (null, 3, 'rx-curated', 'H/O Bronchial asthma', 'Past'),
  (null, 4, 'rx-curated', 'H/O COPD', 'Past'),
  (null, 5, 'rx-curated', 'H/O Pulmonary TB', 'Past'),
  (null, 6, 'rx-curated', 'H/O CKD', 'Past'),
  (null, 7, 'rx-curated', 'H/O CLD', 'Past'),
  (null, 8, 'rx-curated', 'H/O Stroke', 'Past'),
  (null, 9, 'rx-curated', 'H/O Hypothyroidism', 'Past'),
  (null, 10, 'rx-curated', 'H/O Hyperthyroidism', 'Past'),
  (null, 11, 'rx-curated', 'H/O Epilepsy', 'Past'),
  (null, 12, 'rx-curated', 'H/O Jaundice', 'Past'),
  (null, 13, 'rx-curated', 'H/O Peptic ulcer disease', 'Past'),
  (null, 14, 'rx-curated', 'H/O Allergic rhinitis', 'Past'),
  (null, 15, 'rx-curated', 'H/O Hospital admission', 'Past'),
  (null, 16, 'rx-curated', 'H/O Blood transfusion', 'Past'),
  (null, 17, 'rx-curated', 'No significant past illness', 'Past'),
  (null, 18, 'rx-curated', 'Not a known case of DM/HTN', 'Past'),
  (null, 19, 'rx-curated', 'H/O Operation', 'Surgical'),
  (null, 20, 'rx-curated', 'H/O Trauma', 'Surgical'),
  (null, 21, 'rx-curated', 'No known drug allergy', 'Drug'),
  (null, 22, 'rx-curated', 'Allergic to Penicillin', 'Drug'),
  (null, 23, 'rx-curated', 'Allergic to Sulfa drugs', 'Drug'),
  (null, 24, 'rx-curated', 'Allergic to NSAIDs', 'Drug'),
  (null, 25, 'rx-curated', 'On oral hypoglycaemic agents', 'Drug'),
  (null, 26, 'rx-curated', 'On insulin', 'Drug'),
  (null, 27, 'rx-curated', 'On antihypertensives', 'Drug'),
  (null, 28, 'rx-curated', 'On anticoagulant / antiplatelet', 'Drug'),
  (null, 29, 'rx-curated', 'On steroid', 'Drug'),
  (null, 30, 'rx-curated', 'Took antibiotics before visit', 'Drug'),
  (null, 31, 'rx-curated', 'F/H of DM', 'Family'),
  (null, 32, 'rx-curated', 'F/H of HTN', 'Family'),
  (null, 33, 'rx-curated', 'F/H of IHD', 'Family'),
  (null, 34, 'rx-curated', 'F/H of Asthma', 'Family'),
  (null, 35, 'rx-curated', 'Smoker', 'Social'),
  (null, 36, 'rx-curated', 'Ex-smoker', 'Social'),
  (null, 37, 'rx-curated', 'Non-smoker', 'Social'),
  (null, 38, 'rx-curated', 'Betel nut / Jarda chewer', 'Social'),
  (null, 39, 'rx-curated', 'Alcohol consumption', 'Social'),
  (null, 40, 'rx-curated', 'Pregnant', 'Obstetric'),
  (null, 41, 'rx-curated', 'Lactating mother', 'Obstetric'),
  (null, 42, 'rx-curated', 'Immunization up to date (EPI)', 'Past'),
  ('ent', 43, 'rx-curated', 'H/O Tonsillectomy', 'Surgical'),
  ('ent', 44, 'rx-curated', 'H/O Adenoidectomy', 'Surgical'),
  ('ent', 45, 'rx-curated', 'H/O Ear surgery', 'Surgical'),
  ('ent', 46, 'rx-curated', 'H/O Nasal surgery', 'Surgical'),
  ('ent', 47, 'rx-curated', 'H/O Recurrent ear discharge', 'Past'),
  ('ent', 48, 'rx-curated', 'H/O Recurrent sore throat', 'Past'),
  ('ent', 49, 'rx-curated', 'H/O Water entry into ear', 'Past'),
  ('ent', 50, 'rx-curated', 'H/O Ear cleaning with buds', 'Social'),
  ('ent', 51, 'rx-curated', 'H/O Noise exposure', 'Social'),
  ('ent', 52, 'rx-curated', 'H/O Ear / nose trauma', 'Surgical'),
  ('ent', 53, 'rx-curated', 'H/O Ototoxic drug use', 'Drug'),
  ('ophthalmology', 54, 'rx-curated', 'Uses spectacles', 'Past'),
  ('ophthalmology', 55, 'rx-curated', 'H/O Cataract surgery', 'Surgical'),
  ('ophthalmology', 56, 'rx-curated', 'H/O Eye trauma', 'Surgical'),
  ('ophthalmology', 57, 'rx-curated', 'H/O Glaucoma', 'Past'),
  ('ophthalmology', 58, 'rx-curated', 'Uses topical steroid eye drops', 'Drug'),
  ('ophthalmology', 59, 'rx-curated', 'F/H of Glaucoma', 'Family'),
  ('ophthalmology', 60, 'rx-curated', 'Preterm birth / NICU stay', 'Past'),
  ('vascular', 61, 'rx-curated', 'H/O DVT', 'Past'),
  ('vascular', 62, 'rx-curated', 'H/O Varicose vein surgery', 'Surgical'),
  ('vascular', 63, 'rx-curated', 'H/O Prolonged immobilisation', 'Past'),
  ('vascular', 64, 'rx-curated', 'H/O Prolonged standing', 'Social'),
  ('vascular', 65, 'rx-curated', 'H/O Oral contraceptive use', 'Drug')
) as v(specialty_code, sort_order, source, name, category)
where not exists (select 1 from history_item);



insert into investigation (specialty_code, sort_order, source, name, category)
select specialty_code, sort_order, source, name, category from (values
  (null, 0, 'rx-curated', 'CBC with ESR', 'Haematology'),
  (null, 1, 'rx-curated', 'Hb%', 'Haematology'),
  (null, 2, 'rx-curated', 'Platelet count', 'Haematology'),
  (null, 3, 'rx-curated', 'Blood grouping & Rh typing', 'Haematology'),
  (null, 4, 'rx-curated', 'RBS', 'Biochemistry'),
  (null, 5, 'rx-curated', 'FBS & 2HABF', 'Biochemistry'),
  (null, 6, 'rx-curated', 'HbA1c', 'Biochemistry'),
  (null, 7, 'rx-curated', 'Serum creatinine', 'Biochemistry'),
  (null, 8, 'rx-curated', 'Lipid profile (fasting)', 'Biochemistry'),
  (null, 9, 'rx-curated', 'SGPT (ALT)', 'Biochemistry'),
  (null, 10, 'rx-curated', 'Serum electrolytes', 'Biochemistry'),
  (null, 11, 'rx-curated', 'Serum uric acid', 'Biochemistry'),
  (null, 12, 'rx-curated', 'TSH', 'Hormone'),
  (null, 13, 'rx-curated', 'FT4', 'Hormone'),
  (null, 14, 'rx-curated', 'Urine R/M/E', 'Urine'),
  (null, 15, 'rx-curated', 'Urine C/S', 'Microbiology'),
  (null, 16, 'rx-curated', 'Stool R/M/E', 'Stool'),
  (null, 17, 'rx-curated', 'Dengue NS1 Ag', 'Serology'),
  (null, 18, 'rx-curated', 'Widal test', 'Serology'),
  (null, 19, 'rx-curated', 'Blood C/S', 'Microbiology'),
  (null, 20, 'rx-curated', 'HBsAg', 'Serology'),
  (null, 21, 'rx-curated', 'CRP', 'Serology'),
  (null, 22, 'rx-curated', 'X-ray chest P/A view', 'Imaging'),
  (null, 23, 'rx-curated', 'USG of whole abdomen', 'Imaging'),
  (null, 24, 'rx-curated', 'ECG', 'Cardiology'),
  (null, 25, 'rx-curated', 'Echocardiography', 'Cardiology'),
  ('ent', 26, 'rx-curated', 'Pure tone audiometry (PTA)', 'Audiology'),
  ('ent', 27, 'rx-curated', 'Impedance audiometry (tympanometry)', 'Audiology'),
  ('ent', 28, 'rx-curated', 'OAE', 'Audiology'),
  ('ent', 29, 'rx-curated', 'BERA / ABR', 'Audiology'),
  ('ent', 30, 'rx-curated', 'X-ray PNS (O/M view)', 'Imaging'),
  ('ent', 31, 'rx-curated', 'X-ray soft tissue nasopharynx (lateral view)', 'Imaging'),
  ('ent', 32, 'rx-curated', 'X-ray mastoid (Schüller view)', 'Imaging'),
  ('ent', 33, 'rx-curated', 'CT scan of PNS (coronal & axial)', 'Imaging'),
  ('ent', 34, 'rx-curated', 'HRCT of temporal bone', 'Imaging'),
  ('ent', 35, 'rx-curated', 'Diagnostic nasal endoscopy (DNE)', 'Endoscopy'),
  ('ent', 36, 'rx-curated', 'Video laryngoscopy', 'Endoscopy'),
  ('ent', 37, 'rx-curated', 'Ear swab for C/S', 'Microbiology'),
  ('ent', 38, 'rx-curated', 'Throat swab for C/S', 'Microbiology'),
  ('ent', 39, 'rx-curated', 'FNAC of neck swelling', 'Pathology'),
  ('ent', 40, 'rx-curated', 'Serum IgE', 'Serology'),
  ('ent', 41, 'rx-curated', 'Absolute eosinophil count', 'Haematology'),
  ('ophthalmology', 42, 'rx-curated', 'Visual acuity & refraction', 'Eye'),
  ('ophthalmology', 43, 'rx-curated', 'IOP measurement', 'Eye'),
  ('ophthalmology', 44, 'rx-curated', 'Fundus fluorescein angiography (FFA)', 'Eye'),
  ('ophthalmology', 45, 'rx-curated', 'OCT macula', 'Eye'),
  ('ophthalmology', 46, 'rx-curated', 'OCT RNFL', 'Eye'),
  ('ophthalmology', 47, 'rx-curated', 'Perimetry (visual field)', 'Eye'),
  ('ophthalmology', 48, 'rx-curated', 'B-scan USG of eye', 'Eye'),
  ('ophthalmology', 49, 'rx-curated', 'Biometry (A-scan, keratometry)', 'Eye'),
  ('vascular', 50, 'rx-curated', 'Duplex study of lower limb veins', 'Vascular'),
  ('vascular', 51, 'rx-curated', 'Arterial Doppler of lower limb', 'Vascular'),
  ('vascular', 52, 'rx-curated', 'ABPI', 'Vascular'),
  ('vascular', 53, 'rx-curated', 'CT angiogram of lower limb', 'Vascular'),
  ('vascular', 54, 'rx-curated', 'D-dimer', 'Blood'),
  ('vascular', 55, 'rx-curated', 'S. Albumin', 'Blood'),
  ('vascular', 56, 'rx-curated', 'Pus for C/S', 'Microbiology')
) as v(specialty_code, sort_order, source, name, category)
where not exists (select 1 from investigation);



insert into diagnosis (specialty_code, sort_order, source, name, icd10)
select specialty_code, sort_order, source, name, icd10 from (values
  (null, 0, 'rx-curated', 'Viral fever', 'A99'),
  (null, 1, 'rx-curated', 'Dengue fever', 'A90'),
  (null, 2, 'rx-curated', 'Enteric fever', 'A01.0'),
  (null, 3, 'rx-curated', 'Acute gastroenteritis', 'A09'),
  (null, 4, 'rx-curated', 'Acid peptic disease', 'K27.9'),
  (null, 5, 'rx-curated', 'GERD', 'K21.9'),
  (null, 6, 'rx-curated', 'Irritable bowel syndrome', 'K58.9'),
  (null, 7, 'rx-curated', 'Essential hypertension', 'I10'),
  (null, 8, 'rx-curated', 'Type 2 diabetes mellitus', 'E11.9'),
  (null, 9, 'rx-curated', 'Dyslipidaemia', 'E78.5'),
  (null, 10, 'rx-curated', 'Bronchial asthma', 'J45.9'),
  (null, 11, 'rx-curated', 'COPD', 'J44.9'),
  (null, 12, 'rx-curated', 'Lower respiratory tract infection', 'J22'),
  (null, 13, 'rx-curated', 'Common cold', 'J00'),
  (null, 14, 'rx-curated', 'Urinary tract infection', 'N39.0'),
  (null, 15, 'rx-curated', 'Iron deficiency anaemia', 'D50.9'),
  (null, 16, 'rx-curated', 'Hypothyroidism', 'E03.9'),
  (null, 17, 'rx-curated', 'Osteoarthritis knee', 'M17.9'),
  (null, 18, 'rx-curated', 'Low back pain', 'M54.5'),
  (null, 19, 'rx-curated', 'Tension type headache', 'G44.2'),
  (null, 20, 'rx-curated', 'Migraine', 'G43.9'),
  (null, 21, 'rx-curated', 'Scabies', 'B86'),
  (null, 22, 'rx-curated', 'Tinea corporis', 'B35.4'),
  (null, 23, 'rx-curated', 'Urticaria', 'L50.9'),
  (null, 24, 'rx-curated', 'Anxiety disorder', 'F41.9'),
  ('ent', 25, 'rx-curated', 'CSOM — tubotympanic (mucosal)', 'H66.1'),
  ('ent', 26, 'rx-curated', 'CSOM — atticoantral (squamosal)', 'H66.2'),
  ('ent', 27, 'rx-curated', 'Acute otitis media', 'H66.0'),
  ('ent', 28, 'rx-curated', 'Otitis media with effusion', 'H65.9'),
  ('ent', 29, 'rx-curated', 'Otitis externa', 'H60.9'),
  ('ent', 30, 'rx-curated', 'Otomycosis', 'B36.9'),
  ('ent', 31, 'rx-curated', 'Impacted wax', 'H61.2'),
  ('ent', 32, 'rx-curated', 'Sensorineural hearing loss', 'H90.5'),
  ('ent', 33, 'rx-curated', 'Conductive hearing loss', 'H90.2'),
  ('ent', 34, 'rx-curated', 'BPPV', 'H81.1'),
  ('ent', 35, 'rx-curated', 'Tinnitus', 'H93.1'),
  ('ent', 36, 'rx-curated', 'Allergic rhinitis', 'J30.4'),
  ('ent', 37, 'rx-curated', 'Deviated nasal septum', 'J34.2'),
  ('ent', 38, 'rx-curated', 'Acute rhinosinusitis', 'J01.9'),
  ('ent', 39, 'rx-curated', 'Chronic rhinosinusitis', 'J32.9'),
  ('ent', 40, 'rx-curated', 'Nasal polyp', 'J33.9'),
  ('ent', 41, 'rx-curated', 'Inferior turbinate hypertrophy', 'J34.3'),
  ('ent', 42, 'rx-curated', 'Epistaxis', 'R04.0'),
  ('ent', 43, 'rx-curated', 'Acute tonsillitis', 'J03.9'),
  ('ent', 44, 'rx-curated', 'Chronic tonsillitis', 'J35.0'),
  ('ent', 45, 'rx-curated', 'Adenoid hypertrophy', 'J35.2'),
  ('ent', 46, 'rx-curated', 'Acute pharyngitis', 'J02.9'),
  ('ent', 47, 'rx-curated', 'Chronic pharyngitis', 'J31.2'),
  ('ent', 48, 'rx-curated', 'Peritonsillar abscess (quinsy)', 'J36'),
  ('ent', 49, 'rx-curated', 'Acute laryngitis', 'J04.0'),
  ('ent', 50, 'rx-curated', 'Laryngopharyngeal reflux', 'K21.9'),
  ('ent', 51, 'rx-curated', 'Vocal cord nodule', 'J38.2'),
  ('ent', 52, 'rx-curated', 'Foreign body ear', 'T16'),
  ('ent', 53, 'rx-curated', 'Foreign body nose', 'T17.1'),
  ('ophthalmology', 54, 'rx-curated', 'Refractive error', 'H52.7'),
  ('ophthalmology', 55, 'rx-curated', 'Allergic conjunctivitis', 'H10.1'),
  ('ophthalmology', 56, 'rx-curated', 'Bacterial conjunctivitis', 'H10.0'),
  ('ophthalmology', 57, 'rx-curated', 'Senile cataract', 'H25.9'),
  ('ophthalmology', 58, 'rx-curated', 'Primary open-angle glaucoma', 'H40.1'),
  ('ophthalmology', 59, 'rx-curated', 'Diabetic retinopathy', 'E11.3'),
  ('ophthalmology', 60, 'rx-curated', 'Corneal ulcer', 'H16.0'),
  ('ophthalmology', 61, 'rx-curated', 'Dry eye', 'H04.1'),
  ('ophthalmology', 62, 'rx-curated', 'Chalazion', 'H00.1'),
  ('ophthalmology', 63, 'rx-curated', 'Retinopathy of prematurity', 'H35.1'),
  ('vascular', 64, 'rx-curated', 'Cellulitis of lower limb', 'L03.1'),
  ('vascular', 65, 'rx-curated', 'Varicose veins of lower limb', 'I83.9'),
  ('vascular', 66, 'rx-curated', 'Varicose veins with ulcer', 'I83.0'),
  ('vascular', 67, 'rx-curated', 'Chronic venous insufficiency', 'I87.2'),
  ('vascular', 68, 'rx-curated', 'Deep vein thrombosis of lower limb', 'I80.2'),
  ('vascular', 69, 'rx-curated', 'Peripheral arterial disease', 'I73.9'),
  ('vascular', 70, 'rx-curated', 'Diabetic foot ulcer', 'E11.5'),
  ('vascular', 71, 'rx-curated', 'Lymphoedema', 'I89.0')
) as v(specialty_code, sort_order, source, name, icd10)
where not exists (select 1 from diagnosis);



insert into advice_snippet (specialty_code, sort_order, source, text_bn, text_en, category)
select specialty_code, sort_order, source, text_bn, text_en, category from (values
  (null, 0, 'rx-curated', 'প্রচুর পানি ও তরল খাবার খাবেন', 'Drink plenty of water and fluids', 'general'),
  (null, 1, 'rx-curated', 'পূর্ণ বিশ্রাম নিবেন', 'Take complete rest', 'general'),
  (null, 2, 'rx-curated', 'তেল-চর্বি ও ভাজাপোড়া খাবার পরিহার করুন', 'Avoid oily and fried food', 'diet'),
  (null, 3, 'rx-curated', 'নিয়মিত ৩০ মিনিট হাঁটবেন', 'Walk 30 minutes daily', 'lifestyle'),
  (null, 4, 'rx-curated', 'ধূমপান পরিহার করুন', 'Stop smoking', 'lifestyle'),
  (null, 5, 'rx-curated', 'লবণ কম খাবেন', 'Reduce salt intake', 'diet'),
  (null, 6, 'rx-curated', 'মিষ্টি ও চিনি জাতীয় খাবার পরিহার করুন', 'Avoid sweets and sugar', 'diet'),
  (null, 7, 'rx-curated', 'সময়মতো খাবার খাবেন, দীর্ঘ সময় খালি পেটে থাকবেন না', 'Eat on time; avoid long empty stomach', 'diet'),
  (null, 8, 'rx-curated', 'জ্বর ১০২° ফা. এর বেশি হলে মাথায় পানি দিবেন ও শরীর মুছে দিবেন', 'Sponge if fever exceeds 102°F', 'general'),
  (null, 9, 'rx-curated', 'রিপোর্ট নিয়ে দেখা করবেন', 'Come with the reports', 'follow_up'),
  (null, 10, 'rx-curated', 'পুরাতন প্রেসক্রিপশন সাথে আনবেন', 'Bring old prescriptions', 'follow_up'),
  (null, 11, 'rx-curated', 'অবস্থার অবনতি হলে দ্রুত যোগাযোগ করবেন', 'Contact immediately if condition worsens', 'follow_up'),
  ('ent', 12, 'rx-curated', 'কানে পানি ঢুকাবেন না, গোসলের সময় তুলা দিয়ে কান বন্ধ রাখবেন', 'Keep ear dry; plug with cotton while bathing', 'ear'),
  ('ent', 13, 'rx-curated', 'কটন বাড/কাঠি দিয়ে কান খোঁচাবেন না', 'Do not use cotton buds or sticks in the ear', 'ear'),
  ('ent', 14, 'rx-curated', 'জোরে নাক ঝাড়বেন না', 'Do not blow nose forcefully', 'nose'),
  ('ent', 15, 'rx-curated', 'ধুলাবালি ও ঠান্ডা পরিহার করুন, প্রয়োজনে মাস্ক ব্যবহার করুন', 'Avoid dust and cold; use a mask', 'nose'),
  ('ent', 16, 'rx-curated', 'কুসুম গরম লবণ পানি দিয়ে দিনে ৩–৪ বার গড়গড়া করবেন', 'Warm saline gargle 3–4 times daily', 'throat'),
  ('ent', 17, 'rx-curated', 'ঠান্ডা পানি, আইসক্রিম ও ফ্রিজের খাবার পরিহার করুন', 'Avoid cold water, ice-cream and refrigerated food', 'throat'),
  ('ent', 18, 'rx-curated', 'কুসুম গরম পানির ভাপ নিবেন — দিনে ২ বার', 'Steam inhalation twice daily', 'nose'),
  ('ent', 19, 'rx-curated', 'কণ্ঠস্বরের বিশ্রাম দিবেন, জোরে কথা বলবেন না', 'Voice rest; avoid shouting', 'throat'),
  ('ent', 20, 'rx-curated', 'রাতে খাওয়ার ২ ঘণ্টা পর শুতে যাবেন, মাথা উঁচু করে শোবেন', 'Sleep 2 hours after dinner with head raised', 'throat'),
  ('ent', 21, 'rx-curated', 'নাকের স্প্রে ব্যবহারের আগে বোতল ঝাঁকিয়ে নিবেন', 'Shake nasal spray before use', 'nose'),
  ('ent', 22, 'rx-curated', 'ডিকনজেস্ট্যান্ট নাকের ড্রপ ৫ দিনের বেশি ব্যবহার করবেন না', 'Do not use decongestant nasal drops more than 5 days', 'nose'),
  ('ophthalmology', 23, 'rx-curated', 'চোখ ঘষবেন না, চোখে হাত দেওয়ার আগে হাত ধুয়ে নিবেন', 'Do not rub the eyes; wash hands before touching them', 'eye'),
  ('ophthalmology', 24, 'rx-curated', 'চোখে একাধিক ড্রপ দেওয়ার সময় প্রতিটির মাঝে ১০ মিনিট বিরতি দিবেন', 'Leave 10 minutes between different eye drops', 'eye'),
  ('ophthalmology', 25, 'rx-curated', 'নিজে নিজে চোখে ঔষধ না দিয়ে অন্যের সাহায্যে সাবধানে দিবেন', 'Have someone else put the drops in carefully', 'eye'),
  ('ophthalmology', 26, 'rx-curated', 'রোদে বের হলে কালো চশমা ব্যবহার করবেন', 'Wear dark glasses outdoors', 'eye'),
  ('ophthalmology', 27, 'rx-curated', 'মোবাইল/কম্পিউটার একটানা ব্যবহার করবেন না, মাঝে মাঝে বিরতি দিবেন', 'Take regular breaks from screens', 'eye'),
  ('ophthalmology', 28, 'rx-curated', 'পুনরায় দেখানোর সময় এই ব্যবস্থাপত্র সঙ্গে আনবেন', 'Bring this prescription on the next visit', 'general'),
  ('vascular', 29, 'rx-curated', 'অন্যান্য রোগের ঔষধ পূর্বের নিয়মে চলবে।', 'Continue medicines for other illnesses as before', 'general'),
  ('vascular', 30, 'rx-curated', 'দীর্ঘ সময় দাঁড়িয়ে থাকবেন না।', 'Avoid standing for long periods', 'leg'),
  ('vascular', 31, 'rx-curated', 'শেখানো নিয়মে ব্যায়াম করবেন।', 'Do the exercises as taught', 'leg'),
  ('vascular', 32, 'rx-curated', 'ঘুমানোর সময় পায়ের নিচে বেড ওয়েজ ব্যবহার করবেন।', 'Raise the legs on a bed wedge while sleeping', 'leg'),
  ('vascular', 33, 'rx-curated', 'হাঁটাচলার সময় Graduated Medical Compression Stocking (মোজা) ব্যবহার করবেন (Length Thigh High / Knee High; Pressure 20-30 / 30-40 mmHg)', 'Wear graduated compression stockings while walking', 'leg'),
  ('vascular', 34, 'rx-curated', 'দিনে অন্তত দুই/তিন বার পায়ে তেল (যেকোন) বা লিক্যুইড প্যারাফিন দিবেন।', 'Apply oil or liquid paraffin to the legs 2–3 times daily', 'leg'),
  ('vascular', 35, 'rx-curated', 'ওজন নিয়ন্ত্রণে রাখবেন।', 'Keep your weight under control', 'general'),
  ('vascular', 36, 'rx-curated', 'ধূমপান সম্পূর্ণ বন্ধ করবেন।', 'Stop smoking completely', 'general')
) as v(specialty_code, sort_order, source, text_bn, text_en, category)
where not exists (select 1 from advice_snippet);



insert into instruction_snippet (specialty_code, sort_order, source, text_bn, text_en)
select specialty_code, sort_order, source, text_bn, text_en from (values
  ('ent', 0, 'rx-curated', 'ঔষধ দেওয়ার পর ৫ মিনিট কাত হয়ে থাকবেন', 'Lie on the side for 5 minutes after the drops'),
  (null, 1, 'rx-curated', 'কুলি করে ফেলে দিবেন, গিলবেন না', 'Gargle and spit out; do not swallow'),
  (null, 2, 'rx-curated', 'চুষে খাবেন', 'Suck the tablet'),
  (null, 3, 'rx-curated', 'চিবিয়ে খাবেন', 'Chew the tablet'),
  (null, 4, 'rx-curated', 'আধা গ্লাস পানিতে গুলিয়ে খাবেন', 'Dissolve in half a glass of water'),
  (null, 5, 'rx-curated', 'ব্যথা হলে খাবেন', 'Take when in pain'),
  (null, 6, 'rx-curated', 'জ্বর ১০০° ফা. এর বেশি হলে খাবেন', 'Take if temperature is above 100°F'),
  (null, 7, 'rx-curated', 'আক্রান্ত স্থানে পাতলা করে লাগাবেন', 'Apply a thin layer on the affected area'),
  ('ophthalmology', 8, 'rx-curated', 'দুই চোখে দিবেন', 'In both eyes'),
  ('ophthalmology', 9, 'rx-curated', 'ড্রপ দেওয়ার পর ১–২ মিনিট চোখ বন্ধ রাখবেন', 'Keep eyes closed for 1–2 minutes after the drop'),
  ('ophthalmology', 10, 'rx-curated', 'রাতে ঘুমানোর আগে চোখে লাগাবেন', 'Apply in the eye at bedtime')
) as v(specialty_code, sort_order, source, text_bn, text_en)
where not exists (select 1 from instruction_snippet);



insert into specialty_template (specialty_code, name, version, schema, source)
select 'ent', 'ENT examination', 1, '{"sections":[{"id":"ear","title":"Ear","fields":[{"id":"ear_pinna","label":"Pinna / mastoid","type":"select","lateral":true,"options":["Normal","Tender mastoid","Pre-auricular sinus","Post-aural scar","Swelling"],"normal":"Normal"},{"id":"ear_eac","label":"EAC","type":"multiselect","lateral":true,"options":["Normal","Wax","Impacted wax","Discharge","Oedematous","Fungal debris","Furuncle","Foreign body","Narrow"],"normal":"Normal"},{"id":"ear_tm","label":"TM","type":"select","lateral":true,"options":["Intact","Perforated","Retracted","Bulging","Congested","Dull","Not visible"]},{"id":"ear_tm_map","label":"TM map","type":"eardrum"},{"id":"ear_perf_type","label":"Perforation","type":"select","lateral":true,"options":["Central","Subtotal","Total","Attic","Marginal"]},{"id":"ear_perf_size","label":"Perforation size","type":"select","lateral":true,"options":["Small","Medium","Large"]},{"id":"ear_discharge","label":"Discharge","type":"select","lateral":true,"options":["None","Mucoid","Mucopurulent","Purulent","Foul smelling","Blood stained"],"normal":"None"},{"id":"ear_middle","label":"Middle ear","type":"multiselect","lateral":true,"options":["Healthy mucosa","Oedematous mucosa","Granulation","Polyp","Cholesteatoma flakes"]},{"id":"ear_rinne","label":"Rinne","type":"select","lateral":true,"options":["+ve","−ve","False −ve"]},{"id":"ear_weber","label":"Weber","type":"select","options":["Central","Lateralised to right","Lateralised to left"]},{"id":"ear_abc","label":"ABC","type":"select","lateral":true,"options":["Same as examiner","Reduced"]},{"id":"ear_fistula","label":"Fistula test","type":"select","options":["Negative","Positive"],"normal":"Negative"},{"id":"ear_facial","label":"Facial nerve","type":"select","options":["Intact","Palsy (right)","Palsy (left)"],"normal":"Intact"}]},{"id":"nose","title":"Nose & PNS","fields":[{"id":"nose_external","label":"External nose","type":"select","options":["Normal","Deviated","Saddle","Swelling"],"normal":"Normal"},{"id":"nose_septum","label":"Septum","type":"select","options":["Central","DNS to right","DNS to left","S-shaped DNS","Spur right","Spur left","Perforation","Haematoma"]},{"id":"nose_turbinate","label":"Inferior turbinate","type":"select","lateral":true,"options":["Normal","Hypertrophied","Pale & boggy","Congested"],"normal":"Normal"},{"id":"nose_mucosa","label":"Mucosa","type":"select","options":["Normal","Pale","Congested","Crusting","Atrophic"],"normal":"Normal"},{"id":"nose_discharge","label":"Nasal discharge","type":"select","lateral":true,"options":["None","Watery","Mucoid","Mucopurulent","Blood stained"],"normal":"None"},{"id":"nose_polyp","label":"Polyp","type":"select","lateral":true,"options":["Absent","Present (grade 1)","Present (grade 2)","Present (grade 3)","Antrochoanal"],"normal":"Absent"},{"id":"nose_cottle","label":"Cottle''s test","type":"select","lateral":true,"options":["Negative","Positive"],"normal":"Negative"},{"id":"nose_sinus_tender","label":"Sinus tenderness","type":"multiselect","options":["None","Maxillary","Frontal","Ethmoid"],"normal":"None"},{"id":"nose_map","label":"Nose & sinus map","type":"sketch","sketch":"nose"},{"id":"nose_dne","label":"DNE findings","type":"text"}]},{"id":"throat","title":"Throat & neck","fields":[{"id":"thr_oral","label":"Oral cavity","type":"select","options":["Normal","Ulcer","Coated tongue","Dental caries","Trismus"],"normal":"Normal"},{"id":"thr_tonsil_grade","label":"Tonsil (Brodsky)","type":"select","lateral":true,"options":["Grade 0","Grade 1","Grade 2","Grade 3","Grade 4"]},{"id":"thr_tonsil","label":"Tonsil surface","type":"multiselect","options":["Normal","Congested","Pus in crypts","Membrane","Irwin Moore sign +","Jugulodigastric LN enlarged"],"normal":"Normal"},{"id":"thr_ppw","label":"Posterior pharyngeal wall","type":"select","options":["Normal","Congested","Granular","Post-nasal drip","Bulge"],"normal":"Normal"},{"id":"thr_uvula","label":"Uvula / palate","type":"select","options":["Normal","Pushed (quinsy)","Bifid","Elongated"],"normal":"Normal"},{"id":"thr_oro_map","label":"Oropharynx map","type":"sketch","sketch":"oropharynx"},{"id":"thr_idl","label":"IDL / laryngoscopy","type":"text"},{"id":"thr_cords","label":"Vocal cords","type":"select","options":["Mobile, normal","Nodule","Polyp","Congested","Right cord palsy","Left cord palsy","Growth"]},{"id":"thr_larynx_map","label":"Larynx map","type":"sketch","sketch":"larynx"},{"id":"thr_neck","label":"Neck","type":"select","options":["No lymphadenopathy","LN enlarged right","LN enlarged left","Bilateral LN","Thyroid swelling","Midline swelling"],"normal":"No lymphadenopathy"},{"id":"thr_neck_map","label":"Neck map","type":"sketch","sketch":"neck"}]},{"id":"audiology","title":"Audiology","fields":[{"id":"aud_pta","label":"PTA","type":"audiogram"},{"id":"aud_tymp","label":"Tympanogram","type":"select","lateral":true,"options":["Type A","Type As","Type Ad","Type B","Type C"]},{"id":"aud_reflex","label":"Acoustic reflex","type":"select","lateral":true,"options":["Present","Absent"]}]},{"id":"procedure","title":"Procedure done","fields":[{"id":"proc_done","label":"Procedure","type":"multiselect","options":["Aural toilet / suction","Wax removal (syringing)","Wax removal (instrumental)","Foreign body removal","Ear wick insertion","Epley manoeuvre","Nasal packing","Chemical cautery (Little''s area)","Incision & drainage (quinsy)","FNAC","Nasal endoscopy"]},{"id":"proc_note","label":"Procedure note","type":"text"}]}]}', 'rx-curated'
where not exists (
  select 1 from specialty_template where specialty_code = 'ent' and name = 'ENT examination'
);



insert into specialty_template (specialty_code, name, version, schema, source)
select 'ophthalmology', 'Eye examination', 1, '{"lateralLabels":{"right":"RE","left":"LE","both":"B/E"},"sections":[{"id":"vision","title":"Vision","fields":[{"id":"eye_va","label":"VA (unaided)","type":"select","lateral":true,"options":["6/6","6/9","6/12","6/18","6/24","6/36","6/60","3/60","1/60","CF","HM","PL+","PL−","NPL"]},{"id":"eye_va_ph","label":"VA (pinhole)","type":"select","lateral":true,"options":["6/6","6/9","6/12","6/18","6/24","6/36","6/60","3/60","1/60","CF","HM","PL+","PL−","NPL"]},{"id":"eye_va_glass","label":"VA (with glasses)","type":"select","lateral":true,"options":["6/6","6/9","6/12","6/18","6/24","6/36","6/60","3/60","1/60","CF","HM","PL+","PL−","NPL"]},{"id":"eye_near","label":"Near vision","type":"select","lateral":true,"options":["N6","N8","N10","N12","N18","N24","N36"]},{"id":"eye_refraction","label":"Refraction","type":"text"}]},{"id":"anterior","title":"Anterior segment","fields":[{"id":"eye_lids","label":"Lids","type":"select","lateral":true,"options":["Normal","Swelling","Ptosis","Entropion","Ectropion","Chalazion","Stye","Blepharitis"],"normal":"Normal"},{"id":"eye_conj","label":"Conjunctiva","type":"select","lateral":true,"options":["Normal","Congested","Chemosis","Subconjunctival haemorrhage","Pterygium","Discharge"],"normal":"Normal"},{"id":"eye_cornea","label":"Cornea","type":"select","lateral":true,"options":["Clear","Opacity","Ulcer","Oedema","Foreign body","Keratic precipitates","Abrasion"],"normal":"Clear"},{"id":"eye_ac","label":"AC","type":"select","lateral":true,"options":["Normal depth","Shallow","Cells / flare","Hypopyon","Hyphaema"],"normal":"Normal depth"},{"id":"eye_pupil","label":"Pupil","type":"select","lateral":true,"options":["Round, regular, reactive","Sluggish","Fixed dilated","RAPD present","Irregular"],"normal":"Round, regular, reactive"},{"id":"eye_lens","label":"Lens","type":"select","lateral":true,"options":["Clear","Immature cataract","Mature cataract","Hypermature cataract","PCIOL","Aphakia"],"normal":"Clear"}]},{"id":"iop","title":"IOP","fields":[{"id":"eye_iop","label":"IOP","type":"number","lateral":true,"unit":"mmHg"},{"id":"eye_iop_method","label":"Method","type":"select","options":["NCT","Goldmann","Schiøtz","Digital"]}]},{"id":"fundus","title":"Fundus","fields":[{"id":"eye_fundus","label":"Fundus","type":"select","lateral":true,"options":["NAD","Glaucomatous cupping","Diabetic retinopathy","Hypertensive retinopathy","Papilloedema","Retinal detachment","Not visible"]},{"id":"eye_cdr","label":"CDR","type":"text","lateral":true},{"id":"eye_macula","label":"Macula","type":"select","lateral":true,"options":["Normal","Oedema","Drusen","Scar","Haemorrhage"],"normal":"Normal"}]},{"id":"rop","title":"ROP screening","fields":[{"id":"rop_stage","label":"Stage","type":"select","lateral":true,"options":["Immature, no ROP","Stage 1","Stage 2","Stage 3","Stage 4A","Stage 4B","Stage 5"]},{"id":"rop_zone","label":"Zone","type":"select","lateral":true,"options":["Zone I","Zone II","Zone III"]},{"id":"rop_plus","label":"Plus disease","type":"select","lateral":true,"options":["No plus","Pre-plus","Plus"]},{"id":"rop_result","label":"Result","type":"select","options":["Normal study","ROP — follow-up","ROP — treatment needed"]}]}]}', 'rx-curated'
where not exists (
  select 1 from specialty_template where specialty_code = 'ophthalmology' and name = 'Eye examination'
);



insert into specialty_template (specialty_code, name, version, schema, source)
select 'vascular', 'Vascular examination', 1, '{"sections":[{"id":"pulses","title":"Peripheral pulses","fields":[{"id":"vas_femoral","label":"Femoral","type":"select","lateral":true,"options":["Present","Diminished","Absent"]},{"id":"vas_popliteal","label":"Popliteal","type":"select","lateral":true,"options":["Present","Diminished","Absent"]},{"id":"vas_dp","label":"Dorsalis pedis","type":"select","lateral":true,"options":["Present","Diminished","Absent"]},{"id":"vas_pt","label":"Posterior tibial","type":"select","lateral":true,"options":["Present","Diminished","Absent"]},{"id":"vas_abpi","label":"ABPI","type":"number","lateral":true}]},{"id":"limb","title":"Limb","fields":[{"id":"vas_skin","label":"Skin condition","type":"multiselect","lateral":true,"options":["Normal","Colour change","Redness","Hyperpigmentation","Lipodermatosclerosis","Eczema","Blisters"],"normal":"Normal"},{"id":"vas_ulcer","label":"Ulcer","type":"select","lateral":true,"options":["None","Venous","Arterial","Diabetic","Gangrene"],"normal":"None"},{"id":"vas_oedema","label":"Oedema","type":"select","lateral":true,"options":["None","Pitting","Non-pitting"],"normal":"None"},{"id":"vas_varicose","label":"Varicose veins","type":"select","lateral":true,"options":["None","GSV territory","SSV territory","GSV + SSV"],"normal":"None"},{"id":"vas_calf","label":"Calf tenderness","type":"select","lateral":true,"options":["Absent","Present"],"normal":"Absent"},{"id":"vas_temp","label":"Limb temperature","type":"select","lateral":true,"options":["Normal","Cold","Warm"],"normal":"Normal"},{"id":"vas_ceap","label":"CEAP class","type":"select","lateral":true,"options":["C0","C1","C2","C3","C4a","C4b","C5","C6"]}]}]}', 'rx-curated'
where not exists (
  select 1 from specialty_template where specialty_code = 'vascular' and name = 'Vascular examination'
);



insert into lab_test (code, name, short, unit, kind, department, sort_order, spec, source)
select code, name, short, unit, kind, department, sort_order, spec, source from (values
  ('718-7', 'Haemoglobin', 'Hb', 'g/dL', 'numeric', 'haematology', 0, '{"range":{"male":{"low":13,"high":17},"female":{"low":12,"high":15},"bands":[{"minAgeDays":182,"maxAgeDays":4383,"low":11.5,"high":15.5}]},"aliases":["hb","hgb","hb%","haemoglobin","hemoglobin"],"decimals":1}'::jsonb, 'rx-curated'),
  ('30341-2', 'ESR', 'ESR', 'mm/1st hr', 'numeric', 'haematology', 1, '{"range":{"male":{"high":15},"female":{"high":20}},"aliases":["esr"],"method":"Westergren"}'::jsonb, 'rx-curated'),
  ('789-8', 'Total RBC count', 'RBC', '×10⁶/µL', 'numeric', 'haematology', 2, '{"range":{"male":{"low":4.5,"high":5.5},"female":{"low":3.8,"high":4.8}},"aliases":["rbccount","trbc","totalrbc"],"decimals":2}'::jsonb, 'rx-curated'),
  ('6690-2', 'Total WBC count', 'WBC', '×10³/µL', 'numeric', 'haematology', 3, '{"range":{"low":4,"high":11},"perCmmFrom":1000,"printAs":"per_cmm","aliases":["wbc","tc","totalcount","wbccount"]}'::jsonb, 'rx-curated'),
  ('777-3', 'Platelet count', 'Platelets', '×10³/µL', 'numeric', 'haematology', 4, '{"range":{"low":150,"high":400},"perCmmFrom":5000,"printAs":"per_cmm","aliases":["plt","platelet","platelets","pc"]}'::jsonb, 'rx-curated'),
  ('770-8', 'Neutrophils', 'Neutrophils', '%', 'numeric', 'haematology', 5, '{"range":{"low":40,"high":75},"aliases":["n","neut","neutrophil","neutrophils","poly"]}'::jsonb, 'rx-curated'),
  ('736-9', 'Lymphocytes', 'Lymphocytes', '%', 'numeric', 'haematology', 6, '{"range":{"low":20,"high":45},"aliases":["l","lymph","lymphocyte","lymphocytes"]}'::jsonb, 'rx-curated'),
  ('5905-5', 'Monocytes', 'Monocytes', '%', 'numeric', 'haematology', 7, '{"range":{"low":2,"high":10},"aliases":["mono","monocyte","monocytes"]}'::jsonb, 'rx-curated'),
  ('713-8', 'Eosinophils', 'Eosinophils', '%', 'numeric', 'haematology', 8, '{"range":{"low":1,"high":6},"aliases":["eos","eosinophil","eosinophils"]}'::jsonb, 'rx-curated'),
  ('706-2', 'Basophils', 'Basophils', '%', 'numeric', 'haematology', 9, '{"range":{"high":1},"aliases":["baso","basophil","basophils"]}'::jsonb, 'rx-curated'),
  ('4544-3', 'Haematocrit (PCV)', 'PCV', '%', 'numeric', 'haematology', 10, '{"range":{"male":{"low":40,"high":50},"female":{"low":36,"high":46}},"aliases":["pcv","hct","haematocrit","hematocrit"],"decimals":1}'::jsonb, 'rx-curated'),
  ('787-2', 'Mean corpuscular volume', 'MCV', 'fL', 'numeric', 'haematology', 11, '{"range":{"low":80,"high":100},"aliases":["mcv"],"decimals":1}'::jsonb, 'rx-curated'),
  ('785-6', 'Mean corpuscular haemoglobin', 'MCH', 'pg', 'numeric', 'haematology', 12, '{"range":{"low":27,"high":32},"aliases":["mch"],"decimals":1}'::jsonb, 'rx-curated'),
  ('786-4', 'Mean corpuscular Hb concentration', 'MCHC', 'g/dL', 'numeric', 'haematology', 13, '{"range":{"low":32,"high":36},"aliases":["mchc"],"decimals":1}'::jsonb, 'rx-curated'),
  ('788-0', 'Red cell distribution width', 'RDW-CV', '%', 'numeric', 'haematology', 14, '{"range":{"low":11.5,"high":14.5},"aliases":["rdw","rdwcv"],"decimals":1}'::jsonb, 'rx-curated'),
  ('711-2', 'Circulating eosinophil count', 'CE', '/cumm', 'numeric', 'haematology', 15, '{"range":{"low":40,"high":440},"aliases":["ce","aec"]}'::jsonb, 'rx-curated'),
  ('4679-7', 'Reticulocyte count', 'Retic', '%', 'numeric', 'haematology', 16, '{"range":{"low":0.5,"high":2.5},"aliases":["retic","reticulocyte"],"decimals":1}'::jsonb, 'rx-curated'),
  ('32700-7', 'Malarial parasite (MP)', 'MP', '', 'coded', 'haematology', 17, '{"options":["Not found","P. vivax found","P. falciparum found","Mixed infection"],"normal":["Not found"],"aliases":["mp"]}'::jsonb, 'rx-curated'),
  ('bd-pbf', 'Peripheral blood film', 'PBF', '', 'text', 'haematology', 18, '{"options":["Normocytic normochromic","Microcytic hypochromic","Macrocytic","Dimorphic","Leucocytosis with neutrophilia"],"aliases":["pbf"]}'::jsonb, 'rx-curated'),
  ('bd-bt', 'Bleeding time', 'BT', 'min', 'numeric', 'haematology', 19, '{"range":{"low":1,"high":6},"aliases":["bt"]}'::jsonb, 'rx-curated'),
  ('bd-ct', 'Clotting time', 'CT', 'min', 'numeric', 'haematology', 20, '{"range":{"low":5,"high":11},"aliases":["ct"]}'::jsonb, 'rx-curated'),
  ('14749-6', 'Random blood sugar', 'RBS', 'mmol/L', 'numeric', 'biochemistry', 21, '{"range":{"high":7.8},"aliases":["rbs"],"decimals":1}'::jsonb, 'rx-curated'),
  ('14771-0', 'Fasting blood sugar', 'FBS', 'mmol/L', 'numeric', 'biochemistry', 22, '{"range":{"low":3.9,"high":6.1},"aliases":["fbs"],"decimals":1}'::jsonb, 'rx-curated'),
  ('14761-1', 'Blood sugar 2 h after breakfast', '2HABF', 'mmol/L', 'numeric', 'biochemistry', 23, '{"range":{"high":7.8},"aliases":["2habf","abf","ppbs","2hpp"],"decimals":1}'::jsonb, 'rx-curated'),
  ('bd-ogtt-2h', 'Blood sugar 2 h after 75 g glucose', 'OGTT 2 h', 'mmol/L', 'numeric', 'biochemistry', 24, '{"range":{"high":7.8},"aliases":["ogtt","ogtt2h"],"decimals":1}'::jsonb, 'rx-curated'),
  ('4548-4', 'HbA1c', 'HbA1c', '%', 'numeric', 'biochemistry', 25, '{"range":{"high":5.7},"aliases":["hba1c","a1c"],"decimals":1,"refText":"Normal < 5.7, prediabetes 5.7–6.4, diabetes ≥ 6.5"}'::jsonb, 'rx-curated'),
  ('2160-0', 'Serum creatinine', 'S. creatinine', 'mg/dL', 'numeric', 'biochemistry', 26, '{"range":{"low":0.6,"high":1.2},"aliases":["cr","creat","creatinine","screatinine","scr","screat"],"decimals":2}'::jsonb, 'rx-curated'),
  ('3091-6', 'Blood urea', 'Urea', 'mg/dL', 'numeric', 'biochemistry', 27, '{"range":{"low":15,"high":40},"aliases":["urea","bu","burea"]}'::jsonb, 'rx-curated'),
  ('3094-0', 'Blood urea nitrogen', 'BUN', 'mg/dL', 'numeric', 'biochemistry', 28, '{"range":{"low":7,"high":20},"aliases":["bun"]}'::jsonb, 'rx-curated'),
  ('98979-8', 'eGFR', 'eGFR', 'mL/min/1.73m²', 'numeric', 'biochemistry', 29, '{"range":{"low":90},"aliases":["egfr","gfr"]}'::jsonb, 'rx-curated'),
  ('3084-1', 'Serum uric acid', 'Uric acid', 'mg/dL', 'numeric', 'biochemistry', 30, '{"range":{"male":{"high":7},"female":{"high":6}},"aliases":["ua","uricacid","suricacid"],"decimals":1}'::jsonb, 'rx-curated'),
  ('1975-2', 'Total bilirubin', 'Bilirubin', 'mg/dL', 'numeric', 'biochemistry', 31, '{"range":{"high":1.2},"aliases":["bil","bili","bilirubin","sbilirubin","tbil"],"decimals":2}'::jsonb, 'rx-curated'),
  ('1968-7', 'Direct bilirubin', 'Direct bilirubin', 'mg/dL', 'numeric', 'biochemistry', 32, '{"range":{"high":0.3},"aliases":["dbil","directbilirubin"],"decimals":2}'::jsonb, 'rx-curated'),
  ('1971-1', 'Indirect bilirubin', 'Indirect bilirubin', 'mg/dL', 'numeric', 'biochemistry', 33, '{"range":{"high":0.9},"aliases":["ibil","indirectbilirubin"],"decimals":2}'::jsonb, 'rx-curated'),
  ('1742-6', 'SGPT (ALT)', 'SGPT', 'U/L', 'numeric', 'biochemistry', 34, '{"range":{"high":40},"aliases":["sgpt","alt"]}'::jsonb, 'rx-curated'),
  ('1920-8', 'SGOT (AST)', 'SGOT', 'U/L', 'numeric', 'biochemistry', 35, '{"range":{"high":40},"aliases":["sgot","ast"]}'::jsonb, 'rx-curated'),
  ('6768-6', 'Alkaline phosphatase', 'ALP', 'U/L', 'numeric', 'biochemistry', 36, '{"range":{"low":40,"high":130},"aliases":["alp","alkphos","salp"]}'::jsonb, 'rx-curated'),
  ('2324-2', 'Gamma GT', 'GGT', 'U/L', 'numeric', 'biochemistry', 37, '{"range":{"male":{"high":55},"female":{"high":38}},"aliases":["ggt","ggtp"]}'::jsonb, 'rx-curated'),
  ('2885-2', 'Total protein', 'T. protein', 'g/dL', 'numeric', 'biochemistry', 38, '{"range":{"low":6,"high":8.3},"aliases":["tp","totalprotein","sprotein"],"decimals":1}'::jsonb, 'rx-curated'),
  ('1751-7', 'Serum albumin', 'S. albumin', 'g/dL', 'numeric', 'biochemistry', 39, '{"range":{"low":3.5,"high":5.2},"aliases":["salb","serumalbumin"],"decimals":1}'::jsonb, 'rx-curated'),
  ('10834-0', 'Globulin', 'Globulin', 'g/dL', 'numeric', 'biochemistry', 40, '{"range":{"low":2,"high":3.5},"aliases":["glob","globulin"],"decimals":1}'::jsonb, 'rx-curated'),
  ('1759-0', 'Albumin/globulin ratio', 'A/G ratio', '', 'numeric', 'biochemistry', 41, '{"range":{"low":1.1,"high":2.5},"aliases":["ag","agratio"],"decimals":2}'::jsonb, 'rx-curated'),
  ('2093-3', 'Total cholesterol', 'T. cholesterol', 'mg/dL', 'numeric', 'biochemistry', 42, '{"range":{"high":200},"aliases":["chol","cholesterol","tchol","tcholesterol"],"refText":"Desirable < 200, borderline 200–239, high ≥ 240"}'::jsonb, 'rx-curated'),
  ('2571-8', 'Triglycerides', 'TG', 'mg/dL', 'numeric', 'biochemistry', 43, '{"range":{"high":150},"aliases":["tg","triglyceride","triglycerides"],"refText":"Normal < 150"}'::jsonb, 'rx-curated'),
  ('2085-9', 'HDL cholesterol', 'HDL', 'mg/dL', 'numeric', 'biochemistry', 44, '{"range":{"low":40},"aliases":["hdl"],"refText":"> 40"}'::jsonb, 'rx-curated'),
  ('13457-7', 'LDL cholesterol', 'LDL', 'mg/dL', 'numeric', 'biochemistry', 45, '{"range":{"high":100},"aliases":["ldl"],"refText":"Optimal < 100"}'::jsonb, 'rx-curated'),
  ('13458-5', 'VLDL cholesterol', 'VLDL', 'mg/dL', 'numeric', 'biochemistry', 46, '{"range":{"high":30},"aliases":["vldl"]}'::jsonb, 'rx-curated'),
  ('2951-2', 'Serum sodium', 'Na', 'mmol/L', 'numeric', 'biochemistry', 47, '{"range":{"low":135,"high":145},"aliases":["na","sodium","sna"]}'::jsonb, 'rx-curated'),
  ('2823-3', 'Serum potassium', 'K', 'mmol/L', 'numeric', 'biochemistry', 48, '{"range":{"low":3.5,"high":5.1},"aliases":["k","potassium","sk"],"decimals":1}'::jsonb, 'rx-curated'),
  ('2075-0', 'Serum chloride', 'Cl', 'mmol/L', 'numeric', 'biochemistry', 49, '{"range":{"low":98,"high":107},"aliases":["cl","chloride","scl"]}'::jsonb, 'rx-curated'),
  ('2028-9', 'Bicarbonate', 'HCO₃', 'mmol/L', 'numeric', 'biochemistry', 50, '{"range":{"low":22,"high":29},"aliases":["hco3","bicarb","bicarbonate","tco2"]}'::jsonb, 'rx-curated'),
  ('17861-6', 'Serum calcium', 'Calcium', 'mg/dL', 'numeric', 'biochemistry', 51, '{"range":{"low":8.5,"high":10.5},"aliases":["calcium","sca","scalcium"],"decimals":1}'::jsonb, 'rx-curated'),
  ('2777-1', 'Serum phosphate', 'Phosphate', 'mg/dL', 'numeric', 'biochemistry', 52, '{"range":{"low":2.5,"high":4.5},"aliases":["po4","phosphate","sphosphate","phosphorus"],"decimals":1}'::jsonb, 'rx-curated'),
  ('19123-9', 'Serum magnesium', 'Magnesium', 'mg/dL', 'numeric', 'biochemistry', 53, '{"range":{"low":1.7,"high":2.4},"aliases":["mg","magnesium","smg"],"decimals":1}'::jsonb, 'rx-curated'),
  ('10839-9', 'Troponin I', 'Troponin I', 'ng/mL', 'numeric', 'biochemistry', 54, '{"range":{"high":0.04},"aliases":["trop","tropi","troponin","troponini"],"decimals":3}'::jsonb, 'rx-curated'),
  ('bd-ckmb', 'CK-MB', 'CK-MB', 'U/L', 'numeric', 'biochemistry', 55, '{"range":{"high":25},"aliases":["ckmb"]}'::jsonb, 'rx-curated'),
  ('2157-6', 'Creatine kinase (CPK)', 'CPK', 'U/L', 'numeric', 'biochemistry', 56, '{"range":{"male":{"low":39,"high":308},"female":{"low":26,"high":192}},"aliases":["cpk","ck"]}'::jsonb, 'rx-curated'),
  ('2532-0', 'Lactate dehydrogenase', 'LDH', 'U/L', 'numeric', 'biochemistry', 57, '{"range":{"low":140,"high":280},"aliases":["ldh"]}'::jsonb, 'rx-curated'),
  ('1798-8', 'Serum amylase', 'Amylase', 'U/L', 'numeric', 'biochemistry', 58, '{"range":{"low":28,"high":100},"aliases":["amylase","samylase"]}'::jsonb, 'rx-curated'),
  ('3040-3', 'Serum lipase', 'Lipase', 'U/L', 'numeric', 'biochemistry', 59, '{"range":{"low":13,"high":60},"aliases":["lipase","slipase"]}'::jsonb, 'rx-curated'),
  ('1988-5', 'C-reactive protein', 'CRP', 'mg/L', 'numeric', 'biochemistry', 60, '{"range":{"high":6},"aliases":["crp"]}'::jsonb, 'rx-curated'),
  ('2498-4', 'Serum iron', 'Iron', 'µg/dL', 'numeric', 'biochemistry', 61, '{"range":{"low":60,"high":170},"aliases":["iron","siron"]}'::jsonb, 'rx-curated'),
  ('2500-7', 'Total iron binding capacity', 'TIBC', 'µg/dL', 'numeric', 'biochemistry', 62, '{"range":{"low":250,"high":450},"aliases":["tibc"]}'::jsonb, 'rx-curated'),
  ('2276-4', 'Serum ferritin', 'Ferritin', 'ng/mL', 'numeric', 'biochemistry', 63, '{"range":{"male":{"low":30,"high":400},"female":{"low":13,"high":150}},"aliases":["ferritin","sferritin"]}'::jsonb, 'rx-curated'),
  ('2132-9', 'Vitamin B12', 'Vit B12', 'pg/mL', 'numeric', 'biochemistry', 64, '{"range":{"low":200,"high":900},"aliases":["b12","vitb12"]}'::jsonb, 'rx-curated'),
  ('1989-3', '25-OH vitamin D', 'Vit D', 'ng/mL', 'numeric', 'biochemistry', 65, '{"range":{"low":30,"high":100},"aliases":["vitd","vitamind","25ohd"],"refText":"Deficient < 20, insufficient 20–29, sufficient 30–100"}'::jsonb, 'rx-curated'),
  ('9318-7', 'Urine albumin/creatinine ratio', 'Urine ACR', 'mg/g', 'numeric', 'biochemistry', 66, '{"range":{"high":30},"aliases":["acr","uacr"]}'::jsonb, 'rx-curated'),
  ('bd-urine-qty', 'Urine quantity', 'Quantity', '', 'text', 'clinical_pathology', 67, '{"options":["10 mL","20 mL","30 mL"]}'::jsonb, 'rx-curated'),
  ('5778-6', 'Urine colour', 'Colour', '', 'coded', 'clinical_pathology', 68, '{"options":["Straw","Pale yellow","Yellow","Dark yellow","Amber","Reddish","Brown"],"normal":["Straw","Pale yellow","Yellow"]}'::jsonb, 'rx-curated'),
  ('5767-9', 'Urine appearance', 'Appearance', '', 'coded', 'clinical_pathology', 69, '{"options":["Clear","Slightly hazy","Hazy","Turbid"],"normal":["Clear"]}'::jsonb, 'rx-curated'),
  ('bd-urine-sediment', 'Urine sediment', 'Sediment', '', 'coded', 'clinical_pathology', 70, '{"options":["Nil","Present"],"normal":["Nil"]}'::jsonb, 'rx-curated'),
  ('5811-5', 'Urine specific gravity', 'Sp. gravity', '', 'numeric', 'clinical_pathology', 71, '{"range":{"low":1.005,"high":1.03},"aliases":["sg","spgr"],"decimals":3}'::jsonb, 'rx-curated'),
  ('5803-2', 'Urine pH', 'pH', '', 'numeric', 'clinical_pathology', 72, '{"range":{"low":4.5,"high":8},"aliases":["ph","uph"],"decimals":1}'::jsonb, 'rx-curated'),
  ('20454-5', 'Urine albumin (protein)', 'Albumin', '', 'coded', 'clinical_pathology', 73, '{"options":["Nil","Trace","+","++","+++","++++"],"normal":["Nil"],"aliases":["alb","albumin","protein","ualb"]}'::jsonb, 'rx-curated'),
  ('25428-4', 'Urine sugar', 'Sugar', '', 'coded', 'clinical_pathology', 74, '{"options":["Nil","Trace","+","++","+++","++++"],"normal":["Nil"],"aliases":["usugar","urinesugar"]}'::jsonb, 'rx-curated'),
  ('5797-6', 'Urine ketones', 'Ketones', '', 'coded', 'clinical_pathology', 75, '{"options":["Nil","Trace","+","++","+++","++++"],"normal":["Nil"],"aliases":["ketone","ketones","acetone"]}'::jsonb, 'rx-curated'),
  ('5770-3', 'Urine bilirubin', 'Bilirubin', '', 'coded', 'clinical_pathology', 76, '{"options":["Nil","+","++","+++"],"normal":["Nil"],"aliases":["ubil","urinebilirubin"]}'::jsonb, 'rx-curated'),
  ('5818-0', 'Urine urobilinogen', 'Urobilinogen', '', 'coded', 'clinical_pathology', 77, '{"options":["Normal","Increased"],"normal":["Normal"],"aliases":["urobilinogen"]}'::jsonb, 'rx-curated'),
  ('5802-4', 'Urine nitrite', 'Nitrite', '', 'coded', 'clinical_pathology', 78, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["nitrite"]}'::jsonb, 'rx-curated'),
  ('5794-3', 'Urine blood', 'Blood', '', 'coded', 'clinical_pathology', 79, '{"options":["Nil","Trace","+","++","+++","++++"],"normal":["Nil"],"aliases":["ublood"]}'::jsonb, 'rx-curated'),
  ('5821-4', 'Urine pus cells', 'Pus cells', '/HPF', 'numeric', 'clinical_pathology', 80, '{"range":{"high":5},"aliases":["pus","puscell","puscells"],"allowRange":true}'::jsonb, 'rx-curated'),
  ('13945-1', 'Urine RBC', 'RBC', '/HPF', 'numeric', 'clinical_pathology', 81, '{"range":{"high":2},"aliases":["rbc","urbc"],"allowRange":true}'::jsonb, 'rx-curated'),
  ('11277-1', 'Urine epithelial cells', 'Epithelial cells', '', 'text', 'clinical_pathology', 82, '{"options":["Nil","Occasional","Few","Moderate","Plenty"],"normal":["Nil","Occasional","Few"],"aliases":["epi","epithelial","epithelialcells"]}'::jsonb, 'rx-curated'),
  ('9842-6', 'Urine casts', 'Casts', '', 'text', 'clinical_pathology', 83, '{"options":["Nil","Hyaline cast","Granular cast","RBC cast","WBC cast"],"normal":["Nil","Hyaline cast"],"aliases":["cast","casts"]}'::jsonb, 'rx-curated'),
  ('bd-urine-crystals', 'Urine crystals', 'Crystals', '', 'text', 'clinical_pathology', 84, '{"options":["Nil","Calcium oxalate","Uric acid","Triple phosphate","Amorphous urates","Amorphous phosphates"],"normal":["Nil"],"aliases":["crystal","crystals"]}'::jsonb, 'rx-curated'),
  ('bd-urine-others', 'Urine others', 'Others', '', 'text', 'clinical_pathology', 85, '{"options":["Nil","Yeast cells","Bacteria","Trichomonas"]}'::jsonb, 'rx-curated'),
  ('bd-stool-colour', 'Stool colour', 'Colour', '', 'coded', 'clinical_pathology', 86, '{"options":["Yellowish","Brown","Greenish","Black","Reddish","Clay"],"normal":["Yellowish","Brown"]}'::jsonb, 'rx-curated'),
  ('bd-stool-consistency', 'Stool consistency', 'Consistency', '', 'coded', 'clinical_pathology', 87, '{"options":["Formed","Semi-formed","Soft","Loose","Watery","Mucoid"],"normal":["Formed","Semi-formed","Soft"]}'::jsonb, 'rx-curated'),
  ('bd-stool-mucus', 'Stool mucus', 'Mucus', '', 'coded', 'clinical_pathology', 88, '{"options":["Absent","Present"],"normal":["Absent"]}'::jsonb, 'rx-curated'),
  ('bd-stool-blood', 'Stool blood (visible)', 'Blood', '', 'coded', 'clinical_pathology', 89, '{"options":["Absent","Present"],"normal":["Absent"]}'::jsonb, 'rx-curated'),
  ('2335-8', 'Occult blood test', 'OBT', '', 'coded', 'clinical_pathology', 90, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["obt","occultblood"]}'::jsonb, 'rx-curated'),
  ('bd-stool-reducing', 'Stool reducing substance', 'Reducing substance', '', 'coded', 'clinical_pathology', 91, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["reducing","reducingsubstance"]}'::jsonb, 'rx-curated'),
  ('bd-stool-pus', 'Stool pus cells', 'Pus cells', '/HPF', 'numeric', 'clinical_pathology', 92, '{"range":{"high":5},"allowRange":true}'::jsonb, 'rx-curated'),
  ('bd-stool-rbc', 'Stool RBC', 'RBC', '/HPF', 'numeric', 'clinical_pathology', 93, '{"range":{"high":0},"allowRange":true}'::jsonb, 'rx-curated'),
  ('bd-stool-ova', 'Ova of helminths', 'Ova', '', 'text', 'clinical_pathology', 94, '{"options":["Not found","Ascaris lumbricoides","Trichuris trichiura","Hookworm","Enterobius vermicularis","Taenia"],"normal":["Not found"]}'::jsonb, 'rx-curated'),
  ('bd-stool-cyst', 'Cysts of protozoa', 'Cyst', '', 'text', 'clinical_pathology', 95, '{"options":["Not found","Entamoeba histolytica","Entamoeba coli","Giardia lamblia"],"normal":["Not found"]}'::jsonb, 'rx-curated'),
  ('bd-stool-veg', 'Vegetative forms', 'Vegetative forms', '', 'text', 'clinical_pathology', 96, '{"options":["Not found","E. histolytica (trophozoite)","Giardia lamblia (trophozoite)"],"normal":["Not found"]}'::jsonb, 'rx-curated'),
  ('bd-stool-fat', 'Fat globules', 'Fat globules', '', 'text', 'clinical_pathology', 97, '{"options":["Nil","Few","Present"],"normal":["Nil","Few"]}'::jsonb, 'rx-curated'),
  ('bd-stool-starch', 'Starch granules', 'Starch granules', '', 'text', 'clinical_pathology', 98, '{"options":["Nil","Few","Present"],"normal":["Nil","Few"]}'::jsonb, 'rx-curated'),
  ('bd-stool-vegcells', 'Vegetable cells', 'Vegetable cells', '', 'text', 'clinical_pathology', 99, '{"options":["Nil","Few","Present"]}'::jsonb, 'rx-curated'),
  ('bd-semen-volume', 'Semen volume', 'Volume', 'mL', 'numeric', 'clinical_pathology', 100, '{"range":{"low":1.5},"decimals":1}'::jsonb, 'rx-curated'),
  ('bd-semen-colour', 'Semen colour', 'Colour', '', 'coded', 'clinical_pathology', 101, '{"options":["Greyish white","Yellowish","Reddish"],"normal":["Greyish white"]}'::jsonb, 'rx-curated'),
  ('bd-semen-liquefaction', 'Liquefaction time', 'Liquefaction time', 'min', 'numeric', 'clinical_pathology', 102, '{"range":{"high":60}}'::jsonb, 'rx-curated'),
  ('bd-semen-viscosity', 'Semen viscosity', 'Viscosity', '', 'coded', 'clinical_pathology', 103, '{"options":["Normal","Increased"],"normal":["Normal"]}'::jsonb, 'rx-curated'),
  ('bd-semen-ph', 'Semen pH', 'pH', '', 'numeric', 'clinical_pathology', 104, '{"range":{"low":7.2},"aliases":["semenph"],"decimals":1}'::jsonb, 'rx-curated'),
  ('bd-semen-count', 'Sperm concentration', 'Sperm count', 'million/mL', 'numeric', 'clinical_pathology', 105, '{"range":{"low":15},"aliases":["spermcount"]}'::jsonb, 'rx-curated'),
  ('bd-semen-motility', 'Total motility (PR + NP)', 'Total motility', '%', 'numeric', 'clinical_pathology', 106, '{"range":{"low":40}}'::jsonb, 'rx-curated'),
  ('bd-semen-progressive', 'Progressive motility (PR)', 'Progressive motility', '%', 'numeric', 'clinical_pathology', 107, '{"range":{"low":32}}'::jsonb, 'rx-curated'),
  ('bd-semen-morphology', 'Normal morphology', 'Normal forms', '%', 'numeric', 'clinical_pathology', 108, '{"range":{"low":4}}'::jsonb, 'rx-curated'),
  ('bd-semen-pus', 'Semen pus cells', 'Pus cells', '/HPF', 'numeric', 'clinical_pathology', 109, '{"range":{"high":5},"allowRange":true}'::jsonb, 'rx-curated'),
  ('2106-3', 'Urine for pregnancy test', 'Pregnancy test', '', 'coded', 'clinical_pathology', 110, '{"options":["Negative","Positive"],"aliases":["upt","pregnancy","pregnancytest"]}'::jsonb, 'rx-curated'),
  ('5196-1', 'HBsAg', 'HBsAg', '', 'coded', 'serology', 111, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["hbsag"]}'::jsonb, 'rx-curated'),
  ('16128-1', 'Anti-HCV', 'Anti-HCV', '', 'coded', 'serology', 112, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["antihcv","hcv"]}'::jsonb, 'rx-curated'),
  ('bd-anti-hiv', 'Anti-HIV (1 & 2)', 'Anti-HIV', '', 'coded', 'serology', 113, '{"options":["Non-reactive","Reactive"],"normal":["Non-reactive"],"aliases":["hiv","antihiv"]}'::jsonb, 'rx-curated'),
  ('5292-8', 'VDRL', 'VDRL', '', 'coded', 'serology', 114, '{"options":["Non-reactive","Reactive"],"normal":["Non-reactive"],"aliases":["vdrl"]}'::jsonb, 'rx-curated'),
  ('bd-tpha', 'TPHA', 'TPHA', '', 'coded', 'serology', 115, '{"options":["Non-reactive","Reactive"],"normal":["Non-reactive"],"aliases":["tpha"]}'::jsonb, 'rx-curated'),
  ('bd-widal-to', 'S. Typhi O', 'TO', '', 'titre', 'serology', 116, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["to"]}'::jsonb, 'rx-curated'),
  ('bd-widal-th', 'S. Typhi H', 'TH', '', 'titre', 'serology', 117, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["th"]}'::jsonb, 'rx-curated'),
  ('bd-widal-ah', 'S. Paratyphi A H', 'AH', '', 'titre', 'serology', 118, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["ah"]}'::jsonb, 'rx-curated'),
  ('bd-widal-bh', 'S. Paratyphi B H', 'BH', '', 'titre', 'serology', 119, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["bh"]}'::jsonb, 'rx-curated'),
  ('bd-weilfelix-ox19', 'Proteus OX-19', 'OX-19', '', 'titre', 'serology', 120, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["ox19"]}'::jsonb, 'rx-curated'),
  ('bd-weilfelix-ox2', 'Proteus OX-2', 'OX-2', '', 'titre', 'serology', 121, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["ox2"]}'::jsonb, 'rx-curated'),
  ('bd-weilfelix-oxk', 'Proteus OX-K', 'OX-K', '', 'titre', 'serology', 122, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["oxk"]}'::jsonb, 'rx-curated'),
  ('bd-brucella', 'Brucella abortus', 'Brucella', '', 'titre', 'serology', 123, '{"options":["Nil","1:20","1:40","1:80","1:160","1:320","1:640","1:1280"],"titreSignificant":"1:160","aliases":["brucella"]}'::jsonb, 'rx-curated'),
  ('bd-typhidot-igm', 'Typhidot IgM', 'Typhidot IgM', '', 'coded', 'serology', 124, '{"options":["Negative","Positive"],"normal":["Negative"]}'::jsonb, 'rx-curated'),
  ('bd-typhidot-igg', 'Typhidot IgG', 'Typhidot IgG', '', 'coded', 'serology', 125, '{"options":["Negative","Positive"],"normal":["Negative"]}'::jsonb, 'rx-curated'),
  ('75377-6', 'Dengue NS1 antigen', 'Dengue NS1', '', 'coded', 'serology', 126, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["ns1","denguens1"]}'::jsonb, 'rx-curated'),
  ('bd-dengue-igm', 'Dengue IgM antibody', 'Dengue IgM', '', 'coded', 'serology', 127, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["dengueigm"]}'::jsonb, 'rx-curated'),
  ('bd-dengue-igg', 'Dengue IgG antibody', 'Dengue IgG', '', 'coded', 'serology', 128, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["dengueigg"]}'::jsonb, 'rx-curated'),
  ('bd-ict-malaria', 'ICT for malaria', 'ICT malaria', '', 'coded', 'serology', 129, '{"options":["Negative","P. falciparum positive","P. vivax positive","Mixed positive"],"normal":["Negative"],"aliases":["ictmalaria","ictmp"]}'::jsonb, 'rx-curated'),
  ('bd-ict-kalaazar', 'ICT for kala-azar (rK39)', 'ICT kala-azar', '', 'coded', 'serology', 130, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["ictka","ictkalaazar","rk39"]}'::jsonb, 'rx-curated'),
  ('5370-2', 'ASO titre', 'ASO', 'IU/mL', 'numeric', 'serology', 131, '{"range":{"high":200},"aliases":["aso","asotitre"]}'::jsonb, 'rx-curated'),
  ('bd-ra', 'RA test (rheumatoid factor)', 'RA test', '', 'coded', 'serology', 132, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["ra","ratest","rf"]}'::jsonb, 'rx-curated'),
  ('bd-hpylori', 'H. pylori antibody', 'H. pylori Ab', '', 'coded', 'serology', 133, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["hpylori"]}'::jsonb, 'rx-curated'),
  ('883-9', 'ABO blood group', 'ABO group', '', 'coded', 'blood_bank', 134, '{"options":["A","B","AB","O"],"aliases":["abo","bloodgroup"]}'::jsonb, 'rx-curated'),
  ('10331-7', 'Rh (D) type', 'Rh', '', 'coded', 'blood_bank', 135, '{"options":["Positive","Negative"],"aliases":["rh"]}'::jsonb, 'rx-curated'),
  ('bd-crossmatch', 'Cross matching', 'Cross match', '', 'coded', 'blood_bank', 136, '{"options":["Compatible","Incompatible"],"normal":["Compatible"],"aliases":["crossmatch"]}'::jsonb, 'rx-curated'),
  ('bd-coombs-direct', 'Direct Coombs test', 'Direct Coombs', '', 'coded', 'blood_bank', 137, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["dct"]}'::jsonb, 'rx-curated'),
  ('bd-coombs-indirect', 'Indirect Coombs test', 'Indirect Coombs', '', 'coded', 'blood_bank', 138, '{"options":["Negative","Positive"],"normal":["Negative"],"aliases":["idct"]}'::jsonb, 'rx-curated'),
  ('3016-3', 'TSH', 'TSH', 'µIU/mL', 'numeric', 'hormone', 139, '{"range":{"low":0.4,"high":4.5},"aliases":["tsh"],"decimals":2}'::jsonb, 'rx-curated'),
  ('14920-3', 'Free T4', 'FT4', 'pmol/L', 'numeric', 'hormone', 140, '{"range":{"low":12,"high":22},"aliases":["ft4"],"decimals":1}'::jsonb, 'rx-curated'),
  ('14928-6', 'Free T3', 'FT3', 'pmol/L', 'numeric', 'hormone', 141, '{"range":{"low":3.1,"high":6.8},"aliases":["ft3"],"decimals":1}'::jsonb, 'rx-curated'),
  ('3053-6', 'Total T3', 'T3', 'ng/dL', 'numeric', 'hormone', 142, '{"range":{"low":80,"high":200},"aliases":["t3"]}'::jsonb, 'rx-curated'),
  ('3026-2', 'Total T4', 'T4', 'µg/dL', 'numeric', 'hormone', 143, '{"range":{"low":5,"high":12},"aliases":["t4"],"decimals":1}'::jsonb, 'rx-curated'),
  ('8099-4', 'Anti-TPO antibody', 'Anti-TPO', 'IU/mL', 'numeric', 'hormone', 144, '{"range":{"high":34},"aliases":["antitpo","tpo"]}'::jsonb, 'rx-curated'),
  ('10501-5', 'LH', 'LH', 'mIU/mL', 'numeric', 'hormone', 145, '{"aliases":["lh"],"refText":"Varies with sex and cycle phase"}'::jsonb, 'rx-curated'),
  ('15067-2', 'FSH', 'FSH', 'mIU/mL', 'numeric', 'hormone', 146, '{"aliases":["fsh"],"refText":"Varies with sex and cycle phase"}'::jsonb, 'rx-curated'),
  ('2842-3', 'Prolactin', 'Prolactin', 'ng/mL', 'numeric', 'hormone', 147, '{"range":{"male":{"low":4,"high":15},"female":{"low":4,"high":23}},"aliases":["prolactin","prl"],"decimals":1}'::jsonb, 'rx-curated'),
  ('2243-4', 'Estradiol (E2)', 'Estradiol', 'pg/mL', 'numeric', 'hormone', 148, '{"aliases":["e2","estradiol"],"refText":"Varies with cycle phase"}'::jsonb, 'rx-curated'),
  ('2839-9', 'Progesterone', 'Progesterone', 'ng/mL', 'numeric', 'hormone', 149, '{"aliases":["progesterone"],"refText":"Varies with cycle phase"}'::jsonb, 'rx-curated'),
  ('2986-8', 'Testosterone', 'Testosterone', 'ng/dL', 'numeric', 'hormone', 150, '{"range":{"male":{"low":300,"high":1000},"female":{"low":15,"high":70}},"aliases":["testosterone"]}'::jsonb, 'rx-curated'),
  ('38476-3', 'Anti-Müllerian hormone', 'AMH', 'ng/mL', 'numeric', 'hormone', 151, '{"aliases":["amh"],"refText":"Varies with age","decimals":2}'::jsonb, 'rx-curated'),
  ('21198-7', 'Beta hCG', 'β-hCG', 'mIU/mL', 'numeric', 'hormone', 152, '{"range":{"high":5},"aliases":["bhcg","betahcg","hcg"],"refText":"Non-pregnant < 5"}'::jsonb, 'rx-curated'),
  ('2143-6', 'Serum cortisol', 'Cortisol', 'µg/dL', 'numeric', 'hormone', 153, '{"aliases":["cortisol"],"refText":"Morning (8 am) 6–23","decimals":1}'::jsonb, 'rx-curated'),
  ('2731-8', 'Parathyroid hormone', 'PTH', 'pg/mL', 'numeric', 'hormone', 154, '{"range":{"low":15,"high":65},"aliases":["pth"]}'::jsonb, 'rx-curated'),
  ('1834-1', 'Alpha-fetoprotein', 'AFP', 'ng/mL', 'numeric', 'tumour_marker', 155, '{"range":{"high":10},"aliases":["afp"]}'::jsonb, 'rx-curated'),
  ('2857-1', 'Total PSA', 'PSA', 'ng/mL', 'numeric', 'tumour_marker', 156, '{"range":{"high":4},"aliases":["psa","tpsa"],"decimals":2}'::jsonb, 'rx-curated'),
  ('10886-0', 'Free PSA', 'Free PSA', 'ng/mL', 'numeric', 'tumour_marker', 157, '{"aliases":["fpsa","freepsa"],"decimals":2}'::jsonb, 'rx-curated'),
  ('2039-6', 'Carcinoembryonic antigen', 'CEA', 'ng/mL', 'numeric', 'tumour_marker', 158, '{"range":{"high":5},"aliases":["cea"],"decimals":1}'::jsonb, 'rx-curated'),
  ('10334-1', 'CA-125', 'CA-125', 'U/mL', 'numeric', 'tumour_marker', 159, '{"range":{"high":35},"aliases":["ca125"]}'::jsonb, 'rx-curated'),
  ('24108-3', 'CA 19-9', 'CA 19-9', 'U/mL', 'numeric', 'tumour_marker', 160, '{"range":{"high":37},"aliases":["ca199"]}'::jsonb, 'rx-curated'),
  ('6875-9', 'CA 15-3', 'CA 15-3', 'U/mL', 'numeric', 'tumour_marker', 161, '{"range":{"high":30},"aliases":["ca153"]}'::jsonb, 'rx-curated'),
  ('5902-2', 'Prothrombin time', 'PT', 'sec', 'numeric', 'coagulation', 162, '{"range":{"low":11,"high":13.5},"aliases":["pt"],"decimals":1}'::jsonb, 'rx-curated'),
  ('6301-6', 'INR', 'INR', '', 'numeric', 'coagulation', 163, '{"range":{"low":0.8,"high":1.2},"aliases":["inr"],"decimals":2}'::jsonb, 'rx-curated'),
  ('3173-2', 'Activated partial thromboplastin time', 'APTT', 'sec', 'numeric', 'coagulation', 164, '{"range":{"low":25,"high":35},"aliases":["aptt"],"decimals":1}'::jsonb, 'rx-curated'),
  ('3255-7', 'Fibrinogen', 'Fibrinogen', 'mg/dL', 'numeric', 'coagulation', 165, '{"range":{"low":200,"high":400},"aliases":["fibrinogen"]}'::jsonb, 'rx-curated'),
  ('48065-7', 'D-dimer', 'D-dimer', 'µg/mL FEU', 'numeric', 'coagulation', 166, '{"range":{"high":0.5},"aliases":["ddimer"],"decimals":2}'::jsonb, 'rx-curated'),
  ('630-4', 'Urine culture & sensitivity', 'Urine C/S', '', 'culture', 'microbiology', 167, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["urinecs","urineculture"]}'::jsonb, 'rx-curated'),
  ('600-7', 'Blood culture & sensitivity', 'Blood C/S', '', 'culture', 'microbiology', 168, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["bloodcs","bloodculture"]}'::jsonb, 'rx-curated'),
  ('625-4', 'Stool culture & sensitivity', 'Stool C/S', '', 'culture', 'microbiology', 169, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["stoolcs","stoolculture"]}'::jsonb, 'rx-curated'),
  ('624-7', 'Sputum culture & sensitivity', 'Sputum C/S', '', 'culture', 'microbiology', 170, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["sputumcs","sputumculture"]}'::jsonb, 'rx-curated'),
  ('6462-6', 'Wound / pus culture & sensitivity', 'Pus C/S', '', 'culture', 'microbiology', 171, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["puscs","woundcs","swabcs"]}'::jsonb, 'rx-curated'),
  ('626-2', 'Throat swab culture & sensitivity', 'Throat swab C/S', '', 'culture', 'microbiology', 172, '{"antibiotics":["Amoxicillin","Amoxiclav","Azithromycin","Cefixime","Cefuroxime","Ceftriaxone","Ceftazidime","Cefepime","Ciprofloxacin","Levofloxacin","Cotrimoxazole","Nitrofurantoin","Fosfomycin","Gentamicin","Amikacin","Doxycycline","Piperacillin-tazobactam","Meropenem","Imipenem","Colistin","Vancomycin","Linezolid"],"aliases":["throatcs","throatswab"]}'::jsonb, 'rx-curated'),
  ('664-3', 'Gram stain', 'Gram stain', '', 'text', 'microbiology', 173, '{"options":["No organism seen","Gram positive cocci","Gram positive cocci in clusters","Gram positive cocci in chains","Gram negative bacilli","Gram positive bacilli","Gram negative diplococci"],"normal":["No organism seen"],"aliases":["gram","gramstain"]}'::jsonb, 'rx-curated'),
  ('11545-1', 'AFB (Ziehl-Neelsen stain)', 'AFB', '', 'coded', 'microbiology', 174, '{"options":["No AFB seen","Scanty","1+","2+","3+"],"normal":["No AFB seen"],"aliases":["afb","znstain"]}'::jsonb, 'rx-curated')
) as v(code, name, short, unit, kind, department, sort_order, spec, source)
where not exists (select 1 from lab_test);



insert into lab_panel (key, name, department, sort_order, spec, source)
select key, name, department, sort_order, spec, source from (values
  ('cbc', 'CBC', 'haematology', 0, '{"sections":[{"tests":["718-7","30341-2"]},{"title":"Total count","tests":["789-8","6690-2","777-3"]},{"title":"Differential count","tests":["770-8","736-9","5905-5","713-8","706-2"]},{"title":"RBC indices","tests":["4544-3","787-2","785-6","786-4","788-0"]}],"code":"58410-2","specimen":"Blood (EDTA)","aliases":["cbc","completebloodcount","hbtcdcesr"]}'::jsonb, 'rx-curated'),
  ('sugar', 'Blood sugar', 'biochemistry', 1, '{"sections":[{"tests":["14749-6","14771-0","14761-1","4548-4"]}],"specimen":"Blood","aliases":["bloodsugar","glucose"]}'::jsonb, 'rx-curated'),
  ('rft', 'RFT', 'biochemistry', 2, '{"sections":[{"tests":["2160-0","3091-6","3094-0","98979-8","3084-1"]}],"specimen":"Blood","aliases":["renalfunction","renalfunctiontest"]}'::jsonb, 'rx-curated'),
  ('lft', 'LFT', 'biochemistry', 3, '{"sections":[{"tests":["1975-2","1968-7","1971-1","1742-6","1920-8","6768-6","2324-2","2885-2","1751-7","10834-0","1759-0"]}],"specimen":"Blood","aliases":["liverfunction","liverfunctiontest"]}'::jsonb, 'rx-curated'),
  ('lipid', 'Lipid profile', 'biochemistry', 4, '{"sections":[{"tests":["2093-3","2571-8","2085-9","13457-7","13458-5"]}],"code":"24331-1","specimen":"Blood (fasting)","aliases":["lipidprofile","fastinglipidprofile"]}'::jsonb, 'rx-curated'),
  ('thyroid', 'Thyroid', 'hormone', 5, '{"sections":[{"tests":["3016-3","14920-3","14928-6","3053-6","3026-2","8099-4"]}],"specimen":"Blood","aliases":["thyroid","tft","thyroidprofile"]}'::jsonb, 'rx-curated'),
  ('urine', 'Urine R/M/E', 'clinical_pathology', 6, '{"sections":[{"title":"Physical examination","tests":["bd-urine-qty","5778-6","5767-9","bd-urine-sediment"]},{"title":"Chemical examination","tests":["5811-5","5803-2","20454-5","25428-4","5797-6","5770-3","5818-0","5802-4","5794-3"]},{"title":"Microscopic examination","tests":["5821-4","13945-1","11277-1","9842-6","bd-urine-crystals","bd-urine-others"]}],"code":"24356-8","specimen":"Urine","aliases":["urinere","urinerme","urineroutine","cua"]}'::jsonb, 'rx-curated'),
  ('electrolytes', 'Electrolytes', 'biochemistry', 7, '{"sections":[{"tests":["2951-2","2823-3","2075-0","2028-9"]}],"code":"24326-1","specimen":"Blood","aliases":["electrolytes","serumelectrolytes"]}'::jsonb, 'rx-curated'),
  ('serology', 'Serology', 'serology', 8, '{"sections":[{"tests":["5196-1","16128-1","1988-5"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('esr', 'ESR', 'haematology', 9, '{"sections":[{"tests":["30341-2"]}],"specimen":"Blood (EDTA)"}'::jsonb, 'rx-curated'),
  ('ce', 'Circulating eosinophil count', 'haematology', 10, '{"sections":[{"tests":["711-2"]}],"specimen":"Blood (EDTA)"}'::jsonb, 'rx-curated'),
  ('retic', 'Reticulocyte count', 'haematology', 11, '{"sections":[{"tests":["4679-7"]}],"specimen":"Blood (EDTA)"}'::jsonb, 'rx-curated'),
  ('mp', 'Malarial parasite (MP)', 'haematology', 12, '{"sections":[{"tests":["32700-7"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('pbf', 'Peripheral blood film', 'haematology', 13, '{"sections":[{"tests":["bd-pbf"]}],"specimen":"Blood (EDTA)"}'::jsonb, 'rx-curated'),
  ('bt-ct', 'BT & CT', 'haematology', 14, '{"sections":[{"tests":["bd-bt","bd-ct"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('ogtt', 'OGTT', 'biochemistry', 15, '{"sections":[{"tests":["14771-0","bd-ogtt-2h"]}],"specimen":"Blood","aliases":["ogtt","glucosetolerancetest"]}'::jsonb, 'rx-curated'),
  ('minerals', 'Calcium, phosphate & magnesium', 'biochemistry', 16, '{"sections":[{"tests":["17861-6","2777-1","19123-9"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('cardiac', 'Cardiac enzymes', 'biochemistry', 17, '{"sections":[{"tests":["10839-9","bd-ckmb","2157-6","2532-0"]}],"specimen":"Blood","aliases":["cardiacenzymes","troponin"]}'::jsonb, 'rx-curated'),
  ('pancreas', 'Amylase & lipase', 'biochemistry', 18, '{"sections":[{"tests":["1798-8","3040-3"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('iron', 'Iron profile', 'biochemistry', 19, '{"sections":[{"tests":["2498-4","2500-7","2276-4"]}],"specimen":"Blood","aliases":["ironprofile","ironstudy"]}'::jsonb, 'rx-curated'),
  ('vitamins', 'Vitamin B12 & D', 'biochemistry', 20, '{"sections":[{"tests":["2132-9","1989-3"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('uacr', 'Urine ACR', 'biochemistry', 21, '{"sections":[{"tests":["9318-7"]}],"specimen":"Urine (spot)","aliases":["acr","urineacr","microalbumin"]}'::jsonb, 'rx-curated'),
  ('stool', 'Stool R/M/E', 'clinical_pathology', 22, '{"sections":[{"title":"Physical examination","tests":["bd-stool-colour","bd-stool-consistency","bd-stool-mucus","bd-stool-blood"]},{"title":"Chemical examination","tests":["2335-8","bd-stool-reducing"]},{"title":"Microscopic examination","tests":["bd-stool-pus","bd-stool-rbc","bd-stool-ova","bd-stool-cyst","bd-stool-veg","bd-stool-fat","bd-stool-starch","bd-stool-vegcells"]}],"specimen":"Stool","aliases":["stoolre","stoolrme","stoolroutine"]}'::jsonb, 'rx-curated'),
  ('obt', 'Stool for OBT', 'clinical_pathology', 23, '{"sections":[{"tests":["2335-8"]}],"specimen":"Stool","aliases":["obt","stoolobt"]}'::jsonb, 'rx-curated'),
  ('semen', 'Semen analysis', 'clinical_pathology', 24, '{"sections":[{"title":"Physical examination","tests":["bd-semen-volume","bd-semen-colour","bd-semen-liquefaction","bd-semen-viscosity","bd-semen-ph"]},{"title":"Microscopic examination","tests":["bd-semen-count","bd-semen-motility","bd-semen-progressive","bd-semen-morphology","bd-semen-pus"]}],"specimen":"Semen","aliases":["semenanalysis","semen"]}'::jsonb, 'rx-curated'),
  ('upt', 'Pregnancy test', 'clinical_pathology', 25, '{"sections":[{"tests":["2106-3"]}],"specimen":"Urine","aliases":["upt","urinepregnancytest"]}'::jsonb, 'rx-curated'),
  ('widal', 'Widal test', 'serology', 26, '{"sections":[{"tests":["bd-widal-to","bd-widal-th","bd-widal-ah","bd-widal-bh"]}],"specimen":"Blood","aliases":["widal","widaltest"]}'::jsonb, 'rx-curated'),
  ('febrile', 'Febrile antigen', 'serology', 27, '{"sections":[{"title":"Widal","tests":["bd-widal-to","bd-widal-th","bd-widal-ah","bd-widal-bh"]},{"title":"Weil-Felix","tests":["bd-weilfelix-ox19","bd-weilfelix-ox2","bd-weilfelix-oxk"]},{"title":"Brucella","tests":["bd-brucella"]}],"specimen":"Blood","aliases":["febrileantigen","tripleantigen"]}'::jsonb, 'rx-curated'),
  ('typhidot', 'Typhidot', 'serology', 28, '{"sections":[{"tests":["bd-typhidot-igm","bd-typhidot-igg"]}],"specimen":"Blood","aliases":["typhidot"]}'::jsonb, 'rx-curated'),
  ('dengue', 'Dengue', 'serology', 29, '{"sections":[{"tests":["75377-6","bd-dengue-igm","bd-dengue-igg"]}],"specimen":"Blood","aliases":["dengue","ns1","dengueigmigg"]}'::jsonb, 'rx-curated'),
  ('ict-malaria', 'ICT for malaria', 'serology', 30, '{"sections":[{"tests":["bd-ict-malaria"]}],"specimen":"Blood","aliases":["ictmalaria"]}'::jsonb, 'rx-curated'),
  ('ict-kalaazar', 'ICT for kala-azar', 'serology', 31, '{"sections":[{"tests":["bd-ict-kalaazar"]}],"specimen":"Blood","aliases":["ictkalaazar","rk39"]}'::jsonb, 'rx-curated'),
  ('hiv', 'Anti-HIV', 'serology', 32, '{"sections":[{"tests":["bd-anti-hiv"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('vdrl', 'VDRL & TPHA', 'serology', 33, '{"sections":[{"tests":["5292-8","bd-tpha"]}],"specimen":"Blood","aliases":["vdrl","tpha"]}'::jsonb, 'rx-curated'),
  ('aso', 'ASO titre', 'serology', 34, '{"sections":[{"tests":["5370-2"]}],"specimen":"Blood","aliases":["aso","asotitre"]}'::jsonb, 'rx-curated'),
  ('ra', 'RA test', 'serology', 35, '{"sections":[{"tests":["bd-ra"]}],"specimen":"Blood","aliases":["ra","ratest","rafactor"]}'::jsonb, 'rx-curated'),
  ('hpylori', 'H. pylori antibody', 'serology', 36, '{"sections":[{"tests":["bd-hpylori"]}],"specimen":"Blood","aliases":["hpylori"]}'::jsonb, 'rx-curated'),
  ('grouping', 'Blood grouping & Rh', 'blood_bank', 37, '{"sections":[{"tests":["883-9","10331-7"]}],"specimen":"Blood","aliases":["bloodgrouping","bloodgroup","grouping","abo"]}'::jsonb, 'rx-curated'),
  ('crossmatch', 'Cross matching', 'blood_bank', 38, '{"sections":[{"tests":["bd-crossmatch"]}],"specimen":"Blood","aliases":["crossmatching","crossmatch"]}'::jsonb, 'rx-curated'),
  ('coombs', 'Coombs test', 'blood_bank', 39, '{"sections":[{"tests":["bd-coombs-direct","bd-coombs-indirect"]}],"specimen":"Blood","aliases":["coombs","coombstest"]}'::jsonb, 'rx-curated'),
  ('reproductive', 'Reproductive hormones', 'hormone', 40, '{"sections":[{"tests":["10501-5","15067-2","2842-3","2243-4","2839-9","2986-8","38476-3"]}],"specimen":"Blood","aliases":["lhfsh","hormones"]}'::jsonb, 'rx-curated'),
  ('bhcg', 'Beta hCG', 'hormone', 41, '{"sections":[{"tests":["21198-7"]}],"specimen":"Blood","aliases":["bhcg","betahcg"]}'::jsonb, 'rx-curated'),
  ('cortisol', 'Serum cortisol', 'hormone', 42, '{"sections":[{"tests":["2143-6"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('pth', 'PTH', 'hormone', 43, '{"sections":[{"tests":["2731-8"]}],"specimen":"Blood"}'::jsonb, 'rx-curated'),
  ('tumour', 'Tumour markers', 'tumour_marker', 44, '{"sections":[{"tests":["1834-1","2857-1","10886-0","2039-6","10334-1","24108-3","6875-9"]}],"specimen":"Blood","aliases":["tumourmarker","tumormarker"]}'::jsonb, 'rx-curated'),
  ('coag', 'Coagulation profile', 'coagulation', 45, '{"sections":[{"tests":["5902-2","6301-6","3173-2","3255-7","48065-7"]}],"specimen":"Blood (citrate)","aliases":["ptinr","coagulation","coagulationprofile"]}'::jsonb, 'rx-curated'),
  ('urine-cs', 'Urine C/S', 'microbiology', 46, '{"sections":[{"tests":["630-4"]}],"specimen":"Urine (midstream)","layout":"culture","aliases":["urinecs","urineculture"]}'::jsonb, 'rx-curated'),
  ('blood-cs', 'Blood C/S', 'microbiology', 47, '{"sections":[{"tests":["600-7"]}],"specimen":"Blood","layout":"culture","aliases":["bloodcs","bloodculture"]}'::jsonb, 'rx-curated'),
  ('stool-cs', 'Stool C/S', 'microbiology', 48, '{"sections":[{"tests":["625-4"]}],"specimen":"Stool","layout":"culture","aliases":["stoolcs","stoolculture"]}'::jsonb, 'rx-curated'),
  ('sputum-cs', 'Sputum C/S', 'microbiology', 49, '{"sections":[{"tests":["624-7"]}],"specimen":"Sputum","layout":"culture","aliases":["sputumcs","sputumculture"]}'::jsonb, 'rx-curated'),
  ('pus-cs', 'Pus C/S', 'microbiology', 50, '{"sections":[{"tests":["6462-6"]}],"specimen":"Pus / wound swab","layout":"culture","aliases":["puscs","woundswab"]}'::jsonb, 'rx-curated'),
  ('throat-cs', 'Throat swab C/S', 'microbiology', 51, '{"sections":[{"tests":["626-2"]}],"specimen":"Throat swab","layout":"culture","aliases":["throatswabcs","throatcs"]}'::jsonb, 'rx-curated'),
  ('gram', 'Gram stain', 'microbiology', 52, '{"sections":[{"tests":["664-3"]}],"aliases":["gramstain"]}'::jsonb, 'rx-curated'),
  ('afb', 'AFB stain', 'microbiology', 53, '{"sections":[{"tests":["11545-1"]}],"specimen":"Sputum","aliases":["afb","sputumafb","sputumforafb"]}'::jsonb, 'rx-curated')
) as v(key, name, department, sort_order, spec, source)
where not exists (select 1 from lab_panel);


COMMIT;