// cPanel startup file. apps/web/server.js changes to its own folder.
import("./apps/web/server.js").catch((err) => {
  console.error(err);
  process.exit(1);
});
